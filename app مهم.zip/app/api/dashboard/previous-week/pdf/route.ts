
import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";
import React from "react";
import {
  Document,
  Page,
  Text,
  View,
  StyleSheet,
  Font,
  renderToBuffer,
} from "@react-pdf/renderer";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function createAdminClient() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key =
    process.env.SUPABASE_SECRET_KEY ||
    process.env.SUPABASE_SERVICE_ROLE_KEY;

  if (!url || !key) {
    throw new Error("Supabase server environment variables are missing");
  }

  return createClient(url, key, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
}

const supabaseAuth = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY!
);

let fontLoaded = false;

async function loadArabicFont() {
  if (fontLoaded) return;

  const response = await fetch(
    "https://raw.githubusercontent.com/google/fonts/main/ofl/notonaskharabic/NotoNaskhArabic%5Bwght%5D.ttf"
  );

  if (!response.ok) {
    throw new Error("تعذر تحميل الخط العربي");
  }

  const bytes = Buffer.from(await response.arrayBuffer());

  Font.register({
    family: "NotoArabic",
    src: `data:font/ttf;base64,${bytes.toString("base64")}`,
  });

  fontLoaded = true;
}

const styles = StyleSheet.create({
  page: {
    padding: 28,
    fontSize: 10,
    fontFamily: "NotoArabic",
    color: "#172033",
  },
  header: {
    backgroundColor: "#102b46",
    padding: 16,
    borderRadius: 6,
    marginBottom: 14,
  },
  brand: {
    color: "#ffffff",
    fontSize: 20,
    textAlign: "center",
    marginBottom: 5,
  },
  subtitle: {
    color: "#d8e6f2",
    fontSize: 10,
    textAlign: "center",
  },
  info: {
    marginBottom: 12,
    padding: 10,
    backgroundColor: "#f1f5f9",
    borderRadius: 5,
    lineHeight: 1.7,
  },
  sectionTitle: {
    fontSize: 12,
    marginTop: 10,
    marginBottom: 7,
    color: "#102b46",
  },
  tableHead: {
    flexDirection: "row",
    backgroundColor: "#dce7f0",
    padding: 7,
  },
  tableRow: {
    flexDirection: "row",
    padding: 7,
    borderBottomWidth: 0.5,
    borderBottomColor: "#d8dee7",
  },
  cell: {
    flex: 1,
    textAlign: "right",
    paddingHorizontal: 2,
  },
  empty: {
    padding: 10,
    textAlign: "center",
    color: "#64748b",
  },
  summary: {
    marginTop: 15,
    padding: 12,
    backgroundColor: "#f1f5f9",
    borderRadius: 5,
  },
  summaryRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 7,
  },
  net: {
    borderTopWidth: 1,
    borderTopColor: "#94a3b8",
    paddingTop: 8,
    marginTop: 3,
    fontSize: 13,
  },
  footer: {
    marginTop: 18,
    fontSize: 8,
    textAlign: "center",
    color: "#64748b",
  },
});

function money(value: unknown) {
  const number = Number(value ?? 0);
  return `${(Number.isFinite(number) ? number : 0).toFixed(2)} د.أ`;
}

function dateText(value: string | null | undefined) {
  if (!value) return "-";

  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "-";

  return new Intl.DateTimeFormat("ar-JO", {
    timeZone: "Asia/Amman",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(date);
}

function relationName(value: any): string {
  if (Array.isArray(value)) return value[0]?.full_name || "-";
  return value?.full_name || "-";
}

export async function GET(request: NextRequest) {
  try {
    const authHeader = request.headers.get("authorization") || "";
    const token = authHeader.startsWith("Bearer ")
      ? authHeader.slice(7).trim()
      : "";

    if (!token) {
      return NextResponse.json(
        { error: "يجب تسجيل الدخول أولاً" },
        { status: 401 }
      );
    }

    const { data: authData, error: authError } =
      await supabaseAuth.auth.getUser(token);

    if (authError || !authData.user) {
      return NextResponse.json(
        { error: "جلسة الدخول غير صالحة" },
        { status: 401 }
      );
    }

    const supabase = createAdminClient();

    const { data: user, error: userError } = await supabase
      .from("users")
      .select("id, full_name, phone, role, is_active, deleted_at")
      .eq("id", authData.user.id)
      .maybeSingle();

    if (userError) throw userError;

    if (!user || !user.is_active || user.deleted_at) {
      return NextResponse.json(
        { error: "الحساب غير فعال" },
        { status: 403 }
      );
    }

    const url = new URL(request.url);
    const requestedWeekId = url.searchParams.get("weekId");

    let weekQuery = supabase
      .from("weekly_periods")
      .select("id, start_at, end_at, is_closed")
      .eq("is_closed", true);

    if (requestedWeekId) {
      weekQuery = weekQuery.eq("id", requestedWeekId);
    } else {
      weekQuery = weekQuery
        .order("end_at", { ascending: false })
        .limit(1);
    }

    const { data: week, error: weekError } =
      await weekQuery.maybeSingle();

    if (weekError) throw weekError;

    if (!week) {
      return NextResponse.json(
        { error: "لا يوجد أسبوع مغلق متاح للكشف" },
        { status: 404 }
      );
    }

    const [producedResult, consumedResult, floorResult] =
      await Promise.all([
        supabase
          .from("orders")
          .select(
            "id, order_number, amount, commission_amount, notes, created_at, consumer:users!orders_consumer_id_fkey(full_name)"
          )
          .eq("producer_id", user.id)
          .eq("processed_week_id", week.id)
          .eq("financially_processed", true)
          .neq("status", "cancelled")
          .order("created_at", { ascending: true }),

        supabase
          .from("orders")
          .select(
            "id, order_number, amount, commission_amount, notes, created_at, producer:users!orders_producer_id_fkey(full_name)"
          )
          .eq("consumer_id", user.id)
          .eq("processed_week_id", week.id)
          .eq("financially_processed", true)
          .neq("status", "cancelled")
          .order("created_at", { ascending: true }),

        supabase
          .from("weekly_user_activity")
          .select("floor_charged")
          .eq("user_id", user.id)
          .eq("week_id", week.id)
          .maybeSingle(),
      ]);

    if (producedResult.error) throw producedResult.error;
    if (consumedResult.error) throw consumedResult.error;
    if (floorResult.error) throw floorResult.error;

    const produced = producedResult.data || [];
    const consumed = consumedResult.data || [];

    const productionCommission = produced.reduce(
      (sum, row: any) => sum + Number(row.commission_amount || 0),
      0
    );

    const consumptionCommission = consumed.reduce(
      (sum, row: any) => sum + Number(row.commission_amount || 0),
      0
    );

    const floor = floorResult.data?.floor_charged ? 1 : 0;

    const net = Number(
      (productionCommission - consumptionCommission - floor).toFixed(2)
    );

    const renderRows = (
      rows: any[],
      nameKey: "consumer" | "producer"
    ) =>
      rows.length
        ? rows.map((row) =>
            React.createElement(
              View,
              { style: styles.tableRow, key: row.id },
              React.createElement(
                Text,
                { style: styles.cell },
                dateText(row.created_at)
              ),
              React.createElement(
                Text,
                { style: styles.cell },
                String(row.order_number ?? row.id.slice(0, 8))
              ),
              React.createElement(
                Text,
                { style: styles.cell },
                money(row.amount)
              ),
              React.createElement(
                Text,
                { style: styles.cell },
                money(row.commission_amount)
              ),
              React.createElement(
                Text,
                { style: styles.cell },
                relationName(row[nameKey])
              )
            )
          )
        : [
            React.createElement(
              Text,
              { style: styles.empty, key: "empty" },
              "لا توجد حركات في هذا القسم"
            ),
          ];

    await loadArabicFont();

    const pdf = await renderToBuffer(
      React.createElement(
        Document,
        { title: "كشف الحساب الأسبوعي - خطك VIP" },
        React.createElement(
          Page,
          { size: "A4", style: styles.page },
          React.createElement(
            View,
            { style: styles.header },
            React.createElement(
              Text,
              { style: styles.brand },
              "خطك VIP"
            ),
            React.createElement(
              Text,
              { style: styles.subtitle },
              "كشف الحساب الأسبوعي"
            )
          ),
          React.createElement(
            View,
            { style: styles.info },
            React.createElement(
              Text,
              {},
              `اسم الكابتن: ${user.full_name || "-"}`
            ),
            React.createElement(
              Text,
              {},
              `رقم الهاتف: ${user.phone || "-"}`
            ),
            React.createElement(
              Text,
              {},
              `بداية الأسبوع: ${dateText(week.start_at)}`
            ),
            React.createElement(
              Text,
              {},
              `نهاية الأسبوع: ${dateText(week.end_at)}`
            )
          ),
          React.createElement(
            Text,
            { style: styles.sectionTitle },
            "الإنتاج / الطلبات التي تم إنتاجها"
          ),
          React.createElement(
            View,
            { style: styles.tableHead },
            ...["التاريخ", "رقم الطلب", "القيمة", "العمولة", "المستهلك"].map(
              (label) =>
                React.createElement(
                  Text,
                  { style: styles.cell, key: label },
                  label
                )
            )
          ),
          ...renderRows(produced, "consumer"),
          React.createElement(
            Text,
            { style: styles.sectionTitle },
            "الاستهلاك / الطلبات التي تم استهلاكها"
          ),
          React.createElement(
            View,
            { style: styles.tableHead },
            ...["التاريخ", "رقم الطلب", "القيمة", "العمولة", "المنتج"].map(
              (label) =>
                React.createElement(
                  Text,
                  { style: styles.cell, key: label },
                  label
                )
            )
          ),
          ...renderRows(consumed, "producer"),
          React.createElement(
            View,
            { style: styles.summary },
            React.createElement(
              View,
              { style: styles.summaryRow },
              React.createElement(Text, {}, "عمولة الإنتاج"),
              React.createElement(Text, {}, money(productionCommission))
            ),
            React.createElement(
              View,
              { style: styles.summaryRow },
              React.createElement(Text, {}, "عمولة الاستهلاك"),
              React.createElement(Text, {}, money(consumptionCommission))
            ),
            React.createElement(
              View,
              { style: styles.summaryRow },
              React.createElement(Text, {}, "الأرضية الأسبوعية"),
              React.createElement(Text, {}, money(floor))
            ),
            React.createElement(
              View,
              { style: [styles.summaryRow, styles.net] },
              React.createElement(Text, {}, "صافي الحساب"),
              React.createElement(Text, {}, money(net))
            )
          ),
          React.createElement(
            Text,
            { style: styles.footer },
            "خطك VIP — كشف صادر من النظام، يرجى مراجعة الإدارة عند وجود اختلاف"
          )
        )
      ) as any
    );

    const filename = `khattak-vip-statement-${week.id}.pdf`;

    return new NextResponse(Buffer.from(pdf), {
      status: 200,
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `attachment; filename="${filename}"`,
        "Cache-Control": "no-store, no-cache, must-revalidate",
      },
    });
  } catch (error: any) {
    console.error("PREVIOUS WEEK PDF ERROR:", error);

    return NextResponse.json(
      {
        error: "حدث خطأ أثناء إنشاء كشف الحساب PDF",
        details: error?.message || "Unknown error",
      },
      { status: 500 }
    );
  }
}
