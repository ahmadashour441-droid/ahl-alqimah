
import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const supabasePublishableKey =
  process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY;
const supabaseSecretKey = process.env.SUPABASE_SECRET_KEY;

const configured = Boolean(
  supabaseUrl && supabasePublishableKey && supabaseSecretKey
);

const supabaseAuth = createClient(
  supabaseUrl || "https://placeholder.supabase.co",
  supabasePublishableKey || "placeholder-key",
  {
    auth: {
      autoRefreshToken: false,
      persistSession: false,
    },
  }
);

const supabaseAdmin = createClient(
  supabaseUrl || "https://placeholder.supabase.co",
  supabaseSecretKey || "placeholder-key",
  {
    auth: {
      autoRefreshToken: false,
      persistSession: false,
    },
  }
);

type AdminUser = {
  id: string;
  full_name: string | null;
};

function checkConfiguration() {
  if (!configured) {
    throw new Error(
      "إعدادات Supabase ناقصة. تحقق من NEXT_PUBLIC_SUPABASE_URL وNEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY وSUPABASE_SECRET_KEY."
    );
  }
}

function getToken(request: NextRequest): string | null {
  const authHeader = request.headers.get("authorization");

  if (!authHeader?.startsWith("Bearer ")) {
    return null;
  }

  const token = authHeader.slice(7).trim();
  return token || null;
}

async function getAdminUser(
  request: NextRequest
): Promise<AdminUser | null> {
  checkConfiguration();

  const token = getToken(request);

  if (!token) {
    return null;
  }

  const {
    data: { user },
    error: authError,
  } = await supabaseAuth.auth.getUser(token);

  if (authError || !user) {
    return null;
  }

  const { data: admin, error } = await supabaseAdmin
    .from("users")
    .select("id, full_name")
    .eq("id", user.id)
    .eq("role", "admin")
    .eq("is_active", true)
    .is("deleted_at", null)
    .maybeSingle();

  if (error || !admin) {
    return null;
  }

  return admin;
}

function unauthorized() {
  return NextResponse.json(
    {
      success: false,
      message: "غير مصرح بالدخول. يجب تسجيل الدخول بحساب مدير نشط.",
    },
    { status: 403 }
  );
}

function errorMessage(error: unknown) {
  return error instanceof Error
    ? error.message
    : "حدث خطأ غير متوقع";
}

async function getLatestClosedWeek() {
  const { data, error } = await supabaseAdmin
    .from("weekly_periods")
    .select("id, start_at, end_at, is_closed, closed_at")
    .eq("is_closed", true)
    .lte("end_at", new Date().toISOString())
    .order("end_at", { ascending: false })
    .limit(1)
    .maybeSingle();

  if (error) {
    throw new Error(
      `فشل تحميل الأسبوع المغلق: ${error.message}`
    );
  }

  return data;
}

async function getSettlementForWeek(weekId: string) {
  const { data, error } = await supabaseAdmin
    .from("weekly_settlements")
    .select("id, week_id, settled_at, settled_by, status")
    .eq("week_id", weekId)
    .maybeSingle();

  if (error) {
    throw new Error(
      `فشل تحميل سجل التسوية: ${error.message}`
    );
  }

  return data;
}

async function getSavedSettlementItems(settlementId: string) {
  const { data, error } = await supabaseAdmin
    .from("weekly_settlement_items")
    .select("*")
    .eq("settlement_id", settlementId)
    .order("user_name_snapshot", { ascending: true });

  if (error) {
    throw new Error(
      `فشل تحميل كشوف المستخدمين: ${error.message}`
    );
  }

  return data ?? [];
}

/**
 * إعداد معاينة قبل التسوية.
 *
 * لا يغيّر الأرصدة ولا ينشئ أي سجلات مالية.
 * قيمة التسوية هنا هي الرصيد المتراكم حتى نهاية الأسبوع،
 * بعد استبعاد صافي الحركات التي حدثت بعد نهاية ذلك الأسبوع.
 */
async function getSettlementPreview(week: {
  id: string;
  start_at: string;
  end_at: string;
}) {
  const [usersResult, laterTransactionsResult] =
    await Promise.all([
      supabaseAdmin
        .from("users")
        .select("id, full_name, phone, balance, is_active")
        .is("deleted_at", null)
        .order("full_name", { ascending: true }),

      supabaseAdmin
        .from("transactions")
        .select("user_id, amount, created_at")
        .gte("created_at", week.end_at),
    ]);

  if (usersResult.error) {
    throw new Error(
      `فشل تحميل المستخدمين: ${usersResult.error.message}`
    );
  }

  if (laterTransactionsResult.error) {
    throw new Error(
      `فشل تحميل الحركات المالية اللاحقة: ${laterTransactionsResult.error.message}`
    );
  }

  const laterNetByUser = new Map<string, number>();

  for (const transaction of laterTransactionsResult.data ?? []) {
    const userId = transaction.user_id;

    if (!userId) continue;

    const amount = Number(transaction.amount || 0);
    const previous = laterNetByUser.get(userId) || 0;

    laterNetByUser.set(
      userId,
      Number((previous + amount).toFixed(2))
    );
  }

  return (usersResult.data ?? []).map((user) => {
    const currentBalance = Number(user.balance || 0);
    const laterTransactionsNet = Number(
      (laterNetByUser.get(user.id) || 0).toFixed(2)
    );

    const settlementAmount = Number(
      (currentBalance - laterTransactionsNet).toFixed(2)
    );

    return {
      user_id: user.id,
      user_name_snapshot: user.full_name || "مستخدم",
      phone: user.phone,
      is_active: user.is_active,
      balance_before: currentBalance,
      settlement_amount: settlementAmount,
      later_transactions_net: laterTransactionsNet,
      balance_after: laterTransactionsNet,
      is_preview: true,
    };
  });
}

/* =====================================================
   GET: تحميل معاينة التسوية أو التسوية المحفوظة
===================================================== */

export async function GET(request: NextRequest) {
  try {
    const admin = await getAdminUser(request);

    if (!admin) {
      return unauthorized();
    }

    const week = await getLatestClosedWeek();

    if (!week) {
      return NextResponse.json({
        success: true,
        admin,
        week: null,
        settlement: null,
        settlements: [],
        count: 0,
        total_settlement_amount: 0,
        already_settled: false,
        message: "لا يوجد أسبوع مغلق جاهز للتسوية.",
      });
    }

    const settlement = await getSettlementForWeek(week.id);

    let settlements: any[] = [];

    if (settlement) {
      settlements = await getSavedSettlementItems(settlement.id);

      settlements = settlements.map((item) => ({
        ...item,
        user_id: item.user_id,
        full_name: item.user_name_snapshot || "مستخدم",
        current_balance: Number(item.balance_before || 0),
        amount: Number(item.settlement_amount || 0),
        is_preview: false,
      }));
    } else {
      settlements = await getSettlementPreview({
        id: week.id,
        start_at: week.start_at,
        end_at: week.end_at,
      });

      settlements = settlements.map((item) => ({
        ...item,
        id: item.user_id,
        full_name: item.user_name_snapshot,
        current_balance: item.balance_before,
        amount: item.settlement_amount,
      }));
    }

    const search = (
      request.nextUrl.searchParams.get("search") || ""
    )
      .trim()
      .toLowerCase();

    const filteredSettlements = settlements.filter((item) => {
      if (!search) return true;

      return (
        String(item.full_name || "")
          .toLowerCase()
          .includes(search) ||
        String(item.phone || "").includes(search)
      );
    });

    const totalSettlementAmount = Number(
      filteredSettlements
        .reduce(
          (total, item) =>
            total + Number(item.settlement_amount ?? item.amount ?? 0),
          0
        )
        .toFixed(2)
    );

    return NextResponse.json({
      success: true,
      admin,
      week: {
        id: week.id,
        start_at: week.start_at,
        end_at: week.end_at,
        closed_at: week.closed_at,
      },
      settlement,
      settlements: filteredSettlements,
      // حقول توافق مؤقت مع أجزاء الواجهة القديمة.
      users: filteredSettlements,
      previousWeek: {
        id: week.id,
        start_at: week.start_at,
        end_at: week.end_at,
      },
      total: totalSettlementAmount,
      count: filteredSettlements.length,
      total_settlement_amount: totalSettlementAmount,
      already_settled: Boolean(settlement),
      message: settlement
        ? "تم تحميل التسوية المحفوظة."
        : "هذه معاينة فقط؛ لم يتم تغيير أي رصيد.",
    });
  } catch (error) {
    console.error("ADMIN SETTLEMENTS GET ERROR:", error);

    return NextResponse.json(
      {
        success: false,
        message: "فشل تحميل التسويات.",
        error: errorMessage(error),
      },
      { status: 500 }
    );
  }
}

/* =====================================================
   POST: تنفيذ تسوية الأسبوع كاملًا عبر Supabase RPC
===================================================== */

export async function POST(request: NextRequest) {
  try {
    checkConfiguration();

    const admin = await getAdminUser(request);

    if (!admin) {
      return unauthorized();
    }

    const token = getToken(request);

    if (!token) {
      return unauthorized();
    }

    const week = await getLatestClosedWeek();

    if (!week) {
      return NextResponse.json(
        {
          success: false,
          message: "لا يوجد أسبوع مغلق جاهز للتسوية.",
        },
        { status: 400 }
      );
    }

    const existingSettlement = await getSettlementForWeek(
      week.id
    );

    if (existingSettlement) {
      return NextResponse.json(
        {
          success: false,
          already_settled: true,
          settlement_id: existingSettlement.id,
          message: "هذا الأسبوع تمت تسويته مسبقًا.",
        },
        { status: 409 }
      );
    }

    /*
     * نستخدم رمز جلسة المدير بدل مفتاح الخدمة هنا؛
     * لأن الدالة في PostgreSQL تتحقق من auth.uid()
     * ومن دور المدير باستخدام public.is_admin().
     */
    const supabaseUser = createClient(
      supabaseUrl!,
      supabasePublishableKey!,
      {
        global: {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        },
        auth: {
          autoRefreshToken: false,
          persistSession: false,
        },
      }
    );

    const { data: settlementId, error: rpcError } =
      await supabaseUser.rpc(
        "settle_week_and_zero_balances",
        {
          p_week_id: week.id,
        }
      );

    if (rpcError) {
      console.error("SETTLEMENT RPC ERROR:", rpcError);

      return NextResponse.json(
        {
          success: false,
          message: "فشل تنفيذ التسوية في قاعدة البيانات.",
          error: rpcError.message,
        },
        { status: 400 }
      );
    }

    if (!settlementId) {
      throw new Error(
        "لم تُرجع قاعدة البيانات معرف التسوية بعد التنفيذ."
      );
    }

    return NextResponse.json({
      success: true,
      settlement_id: settlementId,
      week_id: week.id,
      message: "تم تنفيذ تسوية الأسبوع وحفظ كشوف المستخدمين بنجاح.",
    });
  } catch (error) {
    console.error("ADMIN SETTLEMENTS POST ERROR:", error);

    return NextResponse.json(
      {
        success: false,
        message: "تعذر تنفيذ التسوية.",
        error: errorMessage(error),
      },
      { status: 500 }
    );
  }
}
