
import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";
import React from "react";
import {
  Document,
  Page,
  Text,
  View,
  StyleSheet,
  Font,
  renderToBuffer,
} from "@react-pdf/renderer";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const FONT_URL =
  "https://raw.githubusercontent.com/google/fonts/main/ofl/notonaskharabic/NotoNaskhArabic%5Bwght%5D.ttf";

function createAdminClient() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key =
    process.env.SUPABASE_SECRET_KEY ||
    process.env.SUPABASE_SERVICE_ROLE_KEY;

  if (!url || !key) {
    throw new Error("إعدادات Supabase الخاصة بالخادم غير مكتملة");
  }

  return createClient(url, key, {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
    },
  });
}

function createAuthClient() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY;

  if (!url || !key) {
    throw new Error("إعدادات تسجيل الدخول إلى Supabase غير مكتملة");
  }

  return createClient(url, key, {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
    },
  });
}

let fontLoaded = false;
let fontLoading: Promise<void> | null = null;

async function loadArabicFont() {
  if (fontLoaded) return;

  if (!fontLoading) {
    fontLoading = (async () => {
      const response = await fetch(FONT_URL, {
        cache: "force-cache",
      });

      if (!response.ok) {
        throw new Error(
          `تعذر تحميل الخط العربي (${response.status})`
        );
      }

      const fontBuffer = Buffer.from(
        await response.arrayBuffer()
      );

      Font.register({
        family: "AhlAlQimmaArabic",
        src: `data:font/ttf;base64,${fontBuffer.toString("base64")}`,
      });

      fontLoaded = true;
    })();
  }

  try {
    await fontLoading;
  } catch (error) {
    fontLoading = null;
    throw error;
  }
}

const styles = StyleSheet.create({
  page: {
    paddingTop: 28,
    paddingBottom: 40,
    paddingHorizontal: 24,
    fontFamily: "AhlAlQimmaArabic",
    fontSize: 10,
    color: "#172033",
  },
  header: {
    backgroundColor: "#102b46",
    padding: 16,
    borderRadius: 6,
    marginBottom: 16,
  },
  brand: {
    color: "#ffffff",
    fontSize: 23,
    textAlign: "center",
    marginBottom: 4,
  },
  title: {
    color: "#ffffff",
    fontSize: 15,
    textAlign: "center",
  },
  period: {
    color: "#e2e8f0",
    fontSize: 10,
    textAlign: "center",
    marginTop: 7,
  },
  meta: {
    color: "#e2e8f0",
    fontSize: 9,
    textAlign: "center",
    marginTop: 3,
  },
  summary: {
    padding: 12,
    backgroundColor: "#f1f5f9",
    borderRadius: 5,
    marginBottom: 16,
  },
  summaryRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingVertical: 4,
    borderBottomWidth: 0.4,
    borderBottomColor: "#d5dce5",
  },
  summaryLabel: {
    flex: 1,
    textAlign: "right",
  },
  summaryValue: {
    width: 115,
    textAlign: "left",
    fontSize: 10,
  },
  tableHeader: {
    flexDirection: "row",
    backgroundColor: "#dce7f0",
    paddingVertical: 8,
    paddingHorizontal: 4,
    borderTopWidth: 0.7,
    borderBottomWidth: 0.7,
    borderColor: "#aab8c8",
  },
  row: {
    flexDirection: "row",
    paddingVertical: 7,
    paddingHorizontal: 4,
    borderBottomWidth: 0.5,
    borderBottomColor: "#d8dee7",
  },
  name: {
    width: "29%",
    textAlign: "right",
    paddingHorizontal: 3,
  },
  phone: {
    width: "19%",
    textAlign: "center",
    paddingHorizontal: 2,
  },
  balance: {
    width: "17%",
    textAlign: "center",
    paddingHorizontal: 2,
  },
  settlement: {
    width: "19%",
    textAlign: "center",
    paddingHorizontal: 2,
  },
  after: {
    width: "16%",
    textAlign: "center",
    paddingHorizontal: 2,
  },
  totalBox: {
    marginTop: 16,
    padding: 12,
    backgroundColor: "#f1f5f9",
    borderRadius: 5,
  },
  totalText: {
    textAlign: "right",
    marginBottom: 5,
    fontSize: 10,
  },
  footer: {
    position: "absolute",
    bottom: 15,
    left: 24,
    right: 24,
    textAlign: "center",
    color: "#64748b",
    fontSize: 8,
  },
});

type SettlementItem = {
  id: string;
  user_id: string;
  user_name_snapshot: string | null;
  balance_before: number | string | null;
  settlement_amount: number | string | null;
  balance_after: number | string | null;
};

type PdfRow = {
  id: string;
  fullName: string;
  phone: string;
  balanceBefore: number;
  settlementAmount: number;
  balanceAfter: number;
};

function numberValue(value: unknown): number {
  const result = Number(value ?? 0);
  return Number.isFinite(result) ? result : 0;
}

function money(value: number): string {
  return `${value.toFixed(2)} د.أ`;
}

function dateText(value: string | null | undefined): string {
  if (!value) return "-";

  const date = new Date(value);

  if (Number.isNaN(date.getTime())) return "-";

  return new Intl.DateTimeFormat("ar-JO", {
    timeZone: "Asia/Amman",
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  }).format(date);
}

function dateTimeText(
  value: string | null | undefined
): string {
  if (!value) return "-";

  const date = new Date(value);

  if (Number.isNaN(date.getTime())) return "-";

  return new Intl.DateTimeFormat("ar-JO", {
    timeZone: "Asia/Amman",
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    hour12: true,
  }).format(date);
}

async function getAdmin(request: NextRequest) {
  const authorization = request.headers.get("authorization") || "";
  const token = authorization.startsWith("Bearer ")
    ? authorization.slice(7).trim()
    : "";

  if (!token) return null;

  const authClient = createAuthClient();

  const {
    data: { user },
    error: authError,
  } = await authClient.auth.getUser(token);

  if (authError || !user) return null;

  const supabase = createAdminClient();

  const { data: admin, error } = await supabase
    .from("users")
    .select("id, role, is_active, deleted_at")
    .eq("id", user.id)
    .eq("role", "admin")
    .eq("is_active", true)
    .is("deleted_at", null)
    .maybeSingle();

  if (error || !admin) return null;

  return admin;
}

function errorResponse(message: string, status: number) {
  return NextResponse.json(
    {
      success: false,
      message,
    },
    { status }
  );
}

export async function POST(request: NextRequest) {
  try {
    const admin = await getAdmin(request);

    if (!admin) {
      return errorResponse("غير مصرح بالدخول", 403);
    }

    const body = await request.json().catch(() => ({}));

    const settlementId = String(
      body?.settlementId || ""
    ).trim();

    const weekId = String(body?.weekId || "").trim();

    if (!settlementId && !weekId) {
      return errorResponse(
        "يجب إرسال settlementId أو weekId",
        400
      );
    }

    await loadArabicFont();

    const supabase = createAdminClient();

    let settlementQuery = supabase
      .from("weekly_settlements")
      .select("*");

    if (settlementId) {
      settlementQuery = settlementQuery.eq(
        "id",
        settlementId
      );
    } else {
      settlementQuery = settlementQuery.eq(
        "week_id",
        weekId
      );
    }

    const {
      data: settlement,
      error: settlementError,
    } = await settlementQuery.maybeSingle();

    if (settlementError) {
      console.error(
        "SETTLEMENT PDF: LOAD SETTLEMENT",
        settlementError
      );

      return errorResponse(
        "تعذر تحميل بيانات التسوية المحفوظة",
        500
      );
    }

    if (!settlement) {
      return errorResponse(
        "لا توجد تسوية محفوظة لهذا الأسبوع",
        404
      );
    }

    const actualWeekId = String(settlement.week_id || "");

    if (!actualWeekId) {
      return errorResponse(
        "التسوية المحفوظة لا تحتوي على رقم الأسبوع",
        500
      );
    }

    const {
      data: week,
      error: weekError,
    } = await supabase
      .from("weekly_periods")
      .select("id, start_at, end_at, is_closed")
      .eq("id", actualWeekId)
      .maybeSingle();

    if (weekError) {
      console.error("SETTLEMENT PDF: LOAD WEEK", weekError);

      return errorResponse(
        "تعذر تحميل فترة الأسبوع",
        500
      );
    }

    if (!week || !week.is_closed) {
      return errorResponse(
        "لا يمكن إنشاء الكشف قبل إغلاق الأسبوع",
        400
      );
    }

    const {
      data: items,
      error: itemsError,
    } = await supabase
      .from("weekly_settlement_items")
      .select(
        "id, user_id, user_name_snapshot, balance_before, settlement_amount, balance_after"
      )
      .eq("settlement_id", settlement.id)
      .order("created_at", { ascending: true });

    if (itemsError) {
      console.error(
        "SETTLEMENT PDF: LOAD ITEMS",
        itemsError
      );

      return errorResponse(
        "تعذر تحميل تفاصيل التسوية المحفوظة",
        500
      );
    }

    const savedItems = (items || []) as SettlementItem[];

    if (savedItems.length === 0) {
      return errorResponse(
        "لا توجد تفاصيل محفوظة ضمن هذه التسوية",
        404
      );
    }

    const userIds = [
      ...new Set(
        savedItems
          .map((item) => String(item.user_id || ""))
          .filter(Boolean)
      ),
    ];

    const {
      data: users,
      error: usersError,
    } = userIds.length
      ? await supabase
          .from("users")
          .select("id, full_name, phone")
          .in("id", userIds)
      : { data: [], error: null };

    if (usersError) {
      console.error("SETTLEMENT PDF: LOAD USERS", usersError);

      return errorResponse(
        "تعذر تحميل بيانات المستخدمين",
        500
      );
    }

    const usersById = new Map(
      (users || []).map((user) => [
        String(user.id),
        user,
      ])
    );

    const rows: PdfRow[] = savedItems.map((item) => {
      const user = usersById.get(String(item.user_id));

      return {
        id: item.id,
        fullName:
          item.user_name_snapshot ||
          user?.full_name ||
          "مستخدم محذوف",
        phone: user?.phone || "-",
        balanceBefore: numberValue(item.balance_before),
        settlementAmount: numberValue(item.settlement_amount),
        balanceAfter: numberValue(item.balance_after),
      };
    });

    const positiveTotal = Number(
      rows
        .filter((row) => row.settlementAmount > 0)
        .reduce(
          (sum, row) => sum + row.settlementAmount,
          0
        )
        .toFixed(2)
    );

    const negativeTotal = Number(
      rows
        .filter((row) => row.settlementAmount < 0)
        .reduce(
          (sum, row) => sum + Math.abs(row.settlementAmount),
          0
        )
        .toFixed(2)
    );

    const netTotal = Number(
      rows
        .reduce(
          (sum, row) => sum + row.settlementAmount,
          0
        )
        .toFixed(2)
    );

    const pdfDocument = React.createElement(
      Document,
      {
        title: "كشف التسويات الأسبوعية - أهل القمة",
        author: "أهل القمة",
        subject: "كشف مبالغ التسوية المحفوظة في النظام",
      },
      React.createElement(
        Page,
        {
          size: "A4",
          style: styles.page,
          wrap: true,
        },
        React.createElement(
          View,
          { style: styles.header },
          React.createElement(
            Text,
            { style: styles.brand },
            "أهل القمة"
          ),
          React.createElement(
            Text,
            { style: styles.title },
            "كشف التسويات الأسبوعية"
          ),
          React.createElement(
            Text,
            { style: styles.period },
            `الفترة: ${dateText(week.start_at)} - ${dateText(week.end_at)}`
          ),
          React.createElement(
            Text,
            { style: styles.meta },
            `تاريخ تنفيذ التسوية: ${dateTimeText(settlement.settled_at || settlement.created_at)}`
          ),
          React.createElement(
            Text,
            { style: styles.meta },
            `رقم التسوية: ${settlement.id}`
          )
        ),
        React.createElement(
          View,
          { style: styles.summary },
          React.createElement(
            View,
            { style: styles.summaryRow },
            React.createElement(
              Text,
              { style: styles.summaryLabel },
              "عدد المستخدمين"
            ),
            React.createElement(
              Text,
              { style: styles.summaryValue },
              String(rows.length)
            )
          ),
          React.createElement(
            View,
            { style: styles.summaryRow },
            React.createElement(
              Text,
              { style: styles.summaryLabel },
              "إجمالي المبالغ الموجبة"
            ),
            React.createElement(
              Text,
              { style: styles.summaryValue },
              money(positiveTotal)
            )
          ),
          React.createElement(
            View,
            { style: styles.summaryRow },
            React.createElement(
              Text,
              { style: styles.summaryLabel },
              "إجمالي القيم السالبة"
            ),
            React.createElement(
              Text,
              { style: styles.summaryValue },
              money(negativeTotal)
            )
          ),
          React.createElement(
            View,
            { style: styles.summaryRow },
            React.createElement(
              Text,
              { style: styles.summaryLabel },
              "صافي مبالغ التسوية"
            ),
            React.createElement(
              Text,
              { style: styles.summaryValue },
              money(netTotal)
            )
          )
        ),
        React.createElement(
          View,
          { style: styles.tableHeader, fixed: true },
          React.createElement(
            Text,
            { style: styles.name },
            "اسم المستخدم"
          ),
          React.createElement(
            Text,
            { style: styles.phone },
            "الهاتف"
          ),
          React.createElement(
            Text,
            { style: styles.balance },
            "قبل التسوية"
          ),
          React.createElement(
            Text,
            { style: styles.settlement },
            "مبلغ التسوية"
          ),
          React.createElement(
            Text,
            { style: styles.after },
            "بعد التسوية"
          )
        ),
        ...rows.map((row) =>
          React.createElement(
            View,
            {
              style: styles.row,
              key: row.id,
              wrap: false,
            },
            React.createElement(
              Text,
              { style: styles.name },
              row.fullName
            ),
            React.createElement(
              Text,
              { style: styles.phone },
              row.phone
            ),
            React.createElement(
              Text,
              { style: styles.balance },
              money(row.balanceBefore)
            ),
            React.createElement(
              Text,
              { style: styles.settlement },
              money(row.settlementAmount)
            ),
            React.createElement(
              Text,
              { style: styles.after },
              money(row.balanceAfter)
            )
          )
        ),
        React.createElement(
          View,
          { style: styles.totalBox, wrap: false },
          React.createElement(
            Text,
            { style: styles.totalText },
            `إجمالي المبالغ الموجبة: ${money(positiveTotal)}`
          ),
          React.createElement(
            Text,
            { style: styles.totalText },
            `إجمالي القيم السالبة: ${money(negativeTotal)}`
          ),
          React.createElement(
            Text,
            { style: styles.totalText },
            `صافي التسوية: ${money(netTotal)}`
          )
        ),
        React.createElement(
          Text,
          { style: styles.footer, fixed: true },
          "أهل القمة — تقرير صادر من بيانات التسوية المحفوظة في النظام"
        )
      )
    );

    // تمرير المستند كـ any لتفادي تعارض أنواع React و React-PDF.
    const pdfBuffer = await renderToBuffer(
      pdfDocument as any
    );

    const filename = `كشف-التسويات-${dateText(
      week.end_at
    ).replace(/\//g, "-")}.pdf`;

    return new NextResponse(Buffer.from(pdfBuffer), {
      status: 200,
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `attachment; filename*=UTF-8''${encodeURIComponent(
          filename
        )}`,
        "Content-Length": String(pdfBuffer.length),
        "Cache-Control": "no-store, no-cache, must-revalidate",
        Pragma: "no-cache",
      },
    });
  } catch (error: unknown) {
    console.error("ADMIN SETTLEMENT PDF ERROR:", error);

    const message =
      error instanceof Error
        ? error.message
        : "حدث خطأ غير معروف";

    return NextResponse.json(
      {
        success: false,
        message: "حدث خطأ أثناء إنشاء ملف PDF للتسويات",
        error: message,
      },
      { status: 500 }
    );
  }
}
