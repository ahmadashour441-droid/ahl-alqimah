
import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const supabasePublishableKey =
  process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY;
const supabaseSecretKey = process.env.SUPABASE_SECRET_KEY;

const configurationValid = Boolean(
  supabaseUrl && supabasePublishableKey && supabaseSecretKey
);

const supabaseAuth = createClient(
  supabaseUrl || "https://placeholder.supabase.co",
  supabasePublishableKey || "placeholder-key"
);

const supabaseAdmin = createClient(
  supabaseUrl || "https://placeholder.supabase.co",
  supabaseSecretKey || "placeholder-key",
  {
    auth: {
      autoRefreshToken: false,
      persistSession: false,
    },
  }
);

function checkConfiguration() {
  if (!configurationValid) {
    throw new Error(
      "إعدادات Supabase ناقصة. تحقق من NEXT_PUBLIC_SUPABASE_URL وNEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY وSUPABASE_SECRET_KEY."
    );
  }
}

function normalizePhone(phone: string) {
  return phone.replace(/\s+/g, "").trim();
}

function technicalEmail(phone: string) {
  return `${phone}@captainsystem.com`;
}

function errorMessage(error: unknown) {
  return error instanceof Error ? error.message : "حدث خطأ غير متوقع";
}

async function getAdminUser(request: NextRequest) {
  checkConfiguration();

  const authHeader = request.headers.get("authorization");

  if (!authHeader?.startsWith("Bearer ")) {
    return null;
  }

  const token = authHeader.slice(7).trim();

  if (!token) {
    return null;
  }

  const {
    data: { user },
    error: authError,
  } = await supabaseAuth.auth.getUser(token);

  if (authError || !user) {
    return null;
  }

  const { data: admin, error } = await supabaseAdmin
    .from("users")
    .select("id, full_name, phone, role, is_active, deleted_at")
    .eq("id", user.id)
    .eq("role", "admin")
    .eq("is_active", true)
    .is("deleted_at", null)
    .maybeSingle();

  if (error || !admin) {
    return null;
  }

  return admin;
}

function unauthorized() {
  return NextResponse.json(
    {
      success: false,
      message: "غير مصرح بالدخول",
    },
    { status: 403 }
  );
}

/* =========================================================
   GET - تحميل المستخدمين
========================================================= */

export async function GET(request: NextRequest) {
  try {
    const admin = await getAdminUser(request);

    if (!admin) {
      return unauthorized();
    }

    const { data, error } = await supabaseAdmin
      .from("users")
      .select(
        "id, full_name, phone, email, role, balance, is_active, login_password, deleted_at, created_at, updated_at"
      )
      .is("deleted_at", null)
      .order("created_at", { ascending: false });

    if (error) {
      console.error("ADMIN USERS GET ERROR:", error);

      return NextResponse.json(
        {
          success: false,
          message: "فشل تحميل المستخدمين",
          error: error.message,
        },
        { status: 500 }
      );
    }

    return NextResponse.json({
      success: true,
      users: data ?? [],
    });
  } catch (error) {
    console.error("ADMIN USERS GET SERVER ERROR:", error);

    return NextResponse.json(
      {
        success: false,
        message: errorMessage(error),
      },
      { status: 500 }
    );
  }
}

/* =========================================================
   POST - إضافة مستخدم جديد
========================================================= */

export async function POST(request: NextRequest) {
  try {
    const admin = await getAdminUser(request);

    if (!admin) {
      return unauthorized();
    }

    const body = await request.json();

    const fullName = String(body?.full_name || "").trim();
    const phone = normalizePhone(String(body?.phone || ""));
    const password = String(body?.password || "");
    const role = body?.role === "admin" ? "admin" : "user";

    if (!fullName) {
      return NextResponse.json(
        { success: false, message: "يرجى إدخال الاسم الكامل" },
        { status: 400 }
      );
    }

    if (!/^07\d{8}$/.test(phone)) {
      return NextResponse.json(
        {
          success: false,
          message: "رقم الهاتف يجب أن يكون بصيغة 07XXXXXXXX",
        },
        { status: 400 }
      );
    }

    if (password.length < 6) {
      return NextResponse.json(
        {
          success: false,
          message: "كلمة المرور يجب أن تكون 6 أحرف على الأقل",
        },
        { status: 400 }
      );
    }

    const { data: existingPhone, error: phoneError } =
      await supabaseAdmin
        .from("users")
        .select("id, deleted_at")
        .eq("phone", phone)
        .maybeSingle();

    if (phoneError) {
      throw new Error(phoneError.message);
    }

    if (existingPhone) {
      return NextResponse.json(
        {
          success: false,
          message: existingPhone.deleted_at
            ? "رقم الهاتف مرتبط بحساب محذوف سابقًا. استخدم رقمًا آخر."
            : "رقم الهاتف مستخدم مسبقًا",
        },
        { status: 400 }
      );
    }

    const email = technicalEmail(phone);

    const { data: authData, error: authError } =
      await supabaseAdmin.auth.admin.createUser({
        email,
        password,
        email_confirm: true,
      });

    if (authError || !authData.user) {
      return NextResponse.json(
        {
          success: false,
          message: authError?.message || "فشل إنشاء حساب تسجيل الدخول",
        },
        { status: 500 }
      );
    }

    const userId = authData.user.id;

    const { data: newUser, error: insertError } =
      await supabaseAdmin
        .from("users")
        .insert({
          id: userId,
          full_name: fullName,
          phone,
          email,
          role,
          balance: 0,
          is_active: true,
          login_password: password,
          deleted_at: null,
        })
        .select(
          "id, full_name, phone, email, role, balance, is_active, login_password, deleted_at, created_at, updated_at"
        )
        .single();

    if (insertError) {
      console.error("CREATE PUBLIC USER ERROR:", insertError);

      await supabaseAdmin.auth.admin.deleteUser(userId);

      return NextResponse.json(
        {
          success: false,
          message: insertError.message || "فشل إنشاء المستخدم",
        },
        { status: 500 }
      );
    }

    return NextResponse.json({
      success: true,
      message: "تم إضافة المستخدم بنجاح",
      user: newUser,
    });
  } catch (error) {
    console.error("ADMIN USERS POST ERROR:", error);

    return NextResponse.json(
      { success: false, message: errorMessage(error) },
      { status: 500 }
    );
  }
}

/* =========================================================
   PATCH - تعديل بيانات المستخدم أو الرصيد
========================================================= */

export async function PATCH(request: NextRequest) {
  try {
    const admin = await getAdminUser(request);

    if (!admin) {
      return unauthorized();
    }

    const body = await request.json();
    const userId = String(body?.id || "").trim();

    if (!userId) {
      return NextResponse.json(
        { success: false, message: "معرف المستخدم مفقود" },
        { status: 400 }
      );
    }

    /* -----------------------------------------------------
       المسار الأول: تعديل الرصيد أو تصفيره

       أمثلة للطلب:
       { "id": "...", "balance": 0 }
       { "id": "...", "balance": -5.50 }
       { "id": "...", "balance": 12.75 }

       يتم تسجيل التغيير باستخدام apply_balance_change.
    ----------------------------------------------------- */

    if (Object.prototype.hasOwnProperty.call(body, "balance")) {
      const requestedBalance = Number(body.balance);

      if (
        body.balance === null ||
        body.balance === "" ||
        !Number.isFinite(requestedBalance) ||
        Math.abs(requestedBalance) > 100000000
      ) {
        return NextResponse.json(
          { success: false, message: "قيمة الرصيد غير صحيحة" },
          { status: 400 }
        );
      }

      const targetBalance = Number(requestedBalance.toFixed(2));

      const { data: targetUser, error: targetError } =
        await supabaseAdmin
          .from("users")
          .select("id, full_name, phone, role, balance, is_active, deleted_at")
          .eq("id", userId)
          .is("deleted_at", null)
          .maybeSingle();

      if (targetError) {
        throw new Error(targetError.message);
      }

      if (!targetUser) {
        return NextResponse.json(
          { success: false, message: "المستخدم غير موجود" },
          { status: 404 }
        );
      }

      if (targetUser.role === "admin") {
        return NextResponse.json(
          {
            success: false,
            message: "لا يمكن تعديل رصيد حساب الأدمن من هذه الصفحة",
          },
          { status: 400 }
        );
      }

      const currentBalance = Number(targetUser.balance || 0);

      if (!Number.isFinite(currentBalance)) {
        throw new Error("الرصيد الحالي للمستخدم غير صالح");
      }

      const difference = Number(
        (targetBalance - currentBalance).toFixed(2)
      );

      if (difference === 0) {
        return NextResponse.json({
          success: true,
          message: "الرصيد مطابق للقيمة المطلوبة، لم يتم إجراء أي تغيير",
          user: {
            id: targetUser.id,
            full_name: targetUser.full_name,
            balance: currentBalance,
          },
          unchanged: true,
        });
      }

      const description =
        typeof body.description === "string" && body.description.trim()
          ? body.description.trim().slice(0, 500)
          : targetBalance === 0
            ? "تصفير الرصيد بواسطة الإدارة"
            : "تعديل الرصيد بواسطة الإدارة";

      /*
       * مهم:
       * apply_balance_change تضيف p_amount إلى الرصيد الحالي،
       * لذلك نمرر الفرق، وليس الرصيد المستهدف.
       *
       * الدالة تحدّث users.balance وتضيف سجلًا إلى transactions
       * ضمن المعاملة نفسها في قاعدة البيانات.
       */
      const { data: newBalance, error: balanceError } =
        await supabaseAdmin.rpc("apply_balance_change", {
          p_user_id: userId,
          p_amount: difference,
          p_transaction_type: "admin_balance_adjustment",
          p_week_id: null,
          p_order_id: null,
          p_description: description,
          p_created_by: admin.id,
        });

      if (balanceError) {
        console.error("ADMIN BALANCE ADJUSTMENT ERROR:", balanceError);

        return NextResponse.json(
          {
            success: false,
            message: "فشل تعديل الرصيد وتسجيل الحركة المالية",
            error: balanceError.message,
          },
          { status: 500 }
        );
      }

      const finalBalance = Number(newBalance);

      return NextResponse.json({
        success: true,
        message:
          targetBalance === 0
            ? "تم تصفير الرصيد وتسجيل الحركة المالية"
            : "تم تعديل الرصيد وتسجيل الحركة المالية",
        user: {
          id: targetUser.id,
          full_name: targetUser.full_name,
          phone: targetUser.phone,
          balance: finalBalance,
        },
        balance: {
          before: currentBalance,
          after: finalBalance,
          change: difference,
        },
      });
    }

    /* -----------------------------------------------------
       المسار الثاني: تعديل بيانات المستخدم الاعتيادية
    ----------------------------------------------------- */

    const fullName = String(body?.full_name || "").trim();
    const phone = normalizePhone(String(body?.phone || ""));
    const password =
      body?.password !== undefined ? String(body.password) : "";

    const role = body?.role === "admin" ? "admin" : "user";
    const isActive = body?.is_active === true;

    if (!fullName) {
      return NextResponse.json(
        { success: false, message: "يرجى إدخال الاسم الكامل" },
        { status: 400 }
      );
    }

    if (!/^07\d{8}$/.test(phone)) {
      return NextResponse.json(
        {
          success: false,
          message: "رقم الهاتف يجب أن يكون بصيغة 07XXXXXXXX",
        },
        { status: 400 }
      );
    }

    if (password && password.length < 6) {
      return NextResponse.json(
        {
          success: false,
          message: "كلمة المرور يجب أن تكون 6 أحرف على الأقل",
        },
        { status: 400 }
      );
    }

    if (userId === admin.id) {
      if (!isActive) {
        return NextResponse.json(
          {
            success: false,
            message: "لا يمكنك إيقاف حساب الأدمن الذي تستخدمه حاليًا",
          },
          { status: 400 }
        );
      }

      if (role !== "admin") {
        return NextResponse.json(
          {
            success: false,
            message: "لا يمكنك إزالة صلاحية الأدمن من حسابك الحالي",
          },
          { status: 400 }
        );
      }
    }

    const { data: existingUser, error: existingError } =
      await supabaseAdmin
        .from("users")
        .select(
          "id, full_name, phone, email, role, balance, is_active, deleted_at"
        )
        .eq("id", userId)
        .is("deleted_at", null)
        .maybeSingle();

    if (existingError) {
      throw new Error(existingError.message);
    }

    if (!existingUser) {
      return NextResponse.json(
        { success: false, message: "المستخدم غير موجود" },
        { status: 404 }
      );
    }

    const { data: duplicatePhone, error: duplicateError } =
      await supabaseAdmin
        .from("users")
        .select("id")
        .eq("phone", phone)
        .neq("id", userId)
        .is("deleted_at", null)
        .maybeSingle();

    if (duplicateError) {
      throw new Error(duplicateError.message);
    }

    if (duplicatePhone) {
      return NextResponse.json(
        { success: false, message: "رقم الهاتف مستخدم من حساب آخر" },
        { status: 400 }
      );
    }

    const oldPhone = existingUser.phone;
    const newEmail = technicalEmail(phone);

    if (oldPhone !== phone) {
      const { error: emailError } =
        await supabaseAdmin.auth.admin.updateUserById(userId, {
          email: newEmail,
          email_confirm: true,
        });

      if (emailError) {
        return NextResponse.json(
          {
            success: false,
            message: "فشل تحديث رقم الهاتف في نظام تسجيل الدخول",
            error: emailError.message,
          },
          { status: 500 }
        );
      }
    }

    if (password) {
      const { error: passwordError } =
        await supabaseAdmin.auth.admin.updateUserById(userId, {
          password,
        });

      if (passwordError) {
        return NextResponse.json(
          {
            success: false,
            message: "فشل تحديث كلمة المرور",
            error: passwordError.message,
          },
          { status: 500 }
        );
      }
    }

    const updateData: Record<string, unknown> = {
      full_name: fullName,
      phone,
      email: newEmail,
      role,
      is_active: isActive,
      updated_at: new Date().toISOString(),
    };

    if (password) {
      updateData.login_password = password;
    }

    const { data: updatedUser, error: updateError } =
      await supabaseAdmin
        .from("users")
        .update(updateData)
        .eq("id", userId)
        .is("deleted_at", null)
        .select(
          "id, full_name, phone, email, role, balance, is_active, login_password, deleted_at, created_at, updated_at"
        )
        .single();

    if (updateError) {
      console.error("ADMIN USER UPDATE ERROR:", updateError);

      return NextResponse.json(
        {
          success: false,
          message: "فشل تحديث بيانات المستخدم",
          error: updateError.message,
        },
        { status: 500 }
      );
    }

    return NextResponse.json({
      success: true,
      message: "تم تحديث بيانات المستخدم بنجاح",
      user: updatedUser,
    });
  } catch (error) {
    console.error("ADMIN USERS PATCH ERROR:", error);

    return NextResponse.json(
      { success: false, message: errorMessage(error) },
      { status: 500 }
    );
  }
}

/* =========================================================
   DELETE - حذف منطقي مع الاحتفاظ بالسجل المالي
========================================================= */

export async function DELETE(request: NextRequest) {
  try {
    const admin = await getAdminUser(request);

    if (!admin) {
      return unauthorized();
    }

    const body = await request.json();
    const userId = String(body?.id || "").trim();

    if (!userId) {
      return NextResponse.json(
        { success: false, message: "معرف المستخدم مفقود" },
        { status: 400 }
      );
    }

    if (userId === admin.id) {
      return NextResponse.json(
        {
          success: false,
          message: "لا يمكنك حذف حساب الأدمن الذي تستخدمه حاليًا",
        },
        { status: 400 }
      );
    }

    const { data: targetUser, error: targetError } =
      await supabaseAdmin
        .from("users")
        .select("id, full_name, phone, role, balance, is_active, deleted_at")
        .eq("id", userId)
        .is("deleted_at", null)
        .maybeSingle();

    if (targetError) {
      throw new Error(targetError.message);
    }

    if (!targetUser) {
      return NextResponse.json(
        { success: false, message: "المستخدم غير موجود" },
        { status: 404 }
      );
    }

    if (Number(targetUser.balance || 0) !== 0) {
      return NextResponse.json(
        {
          success: false,
          message:
            "لا يمكن حذف مستخدم لديه رصيد غير صفري. سوِّ الرصيد أولًا أو أوقف الحساب.",
        },
        { status: 400 }
      );
    }

    const now = new Date().toISOString();

    const { data: deletedUser, error: deleteError } =
      await supabaseAdmin
        .from("users")
        .update({
          is_active: false,
          deleted_at: now,
          updated_at: now,
        })
        .eq("id", userId)
        .is("deleted_at", null)
        .select("id, full_name, phone, role, balance, is_active, deleted_at")
        .single();

    if (deleteError) {
      console.error("SOFT DELETE USER ERROR:", deleteError);

      return NextResponse.json(
        {
          success: false,
          message: "فشل حذف المستخدم من النظام",
          error: deleteError.message,
        },
        { status: 500 }
      );
    }

    const { error: authDisableError } =
      await supabaseAdmin.auth.admin.updateUserById(userId, {
        ban_duration: "876000h",
      });

    if (authDisableError) {
      console.error("AUTH DISABLE USER ERROR:", authDisableError);

      await supabaseAdmin
        .from("users")
        .update({
          is_active: targetUser.is_active,
          deleted_at: null,
          updated_at: new Date().toISOString(),
        })
        .eq("id", userId);

      return NextResponse.json(
        {
          success: false,
          message: "فشل تعطيل تسجيل دخول المستخدم",
          error: authDisableError.message,
        },
        { status: 500 }
      );
    }

    return NextResponse.json({
      success: true,
      message: "تم حذف المستخدم منطقيًا مع الاحتفاظ بسجله المالي",
      user: deletedUser,
    });
  } catch (error) {
    console.error("ADMIN USERS DELETE ERROR:", error);

    return NextResponse.json(
      { success: false, message: errorMessage(error) },
      { status: 500 }
    );
  }
}
