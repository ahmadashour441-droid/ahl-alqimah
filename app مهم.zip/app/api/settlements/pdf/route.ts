
import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";
import React from "react";
import {
  Document,
  Page,
  Text,
  View,
  StyleSheet,
  Font,
  renderToBuffer,
} from "@react-pdf/renderer";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function getClients() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const publicKey = process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY;
  const secretKey = process.env.SUPABASE_SECRET_KEY;

  if (!url || !publicKey || !secretKey) {
    throw new Error("إعدادات Supabase غير مكتملة");
  }

  return {
    auth: createClient(url, publicKey),
    db: createClient(url, secretKey, {
      auth: { autoRefreshToken: false, persistSession: false },
    }),
  };
}

async function authorize(request: NextRequest) {
  const { auth, db } = getClients();
  const header = request.headers.get("authorization");

  if (!header?.startsWith("Bearer ")) return null;

  const { data, error } = await auth.auth.getUser(header.slice(7).trim());
  if (error || !data.user) return null;

  const { data: admin, error: adminError } = await db
    .from("users")
    .select("id, role, is_active, deleted_at")
    .eq("id", data.user.id)
    .eq("role", "admin")
    .eq("is_active", true)
    .is("deleted_at", null)
    .maybeSingle();

  if (adminError || !admin) return null;
  return { db, admin };
}

function money(value: number) {
  return `${Number(value || 0).toFixed(2)} JD`;
}

function dateText(value?: string | null) {
  if (!value) return "-";

  return new Intl.DateTimeFormat("en-GB", {
    timeZone: "Asia/Amman",
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  }).format(new Date(value));
}

const styles = StyleSheet.create({
  page: {
    padding: 32,
    fontSize: 10,
    fontFamily: "NotoArabic",
    color: "#172033",
  },
  header: {
    alignItems: "center",
    marginBottom: 18,
    paddingBottom: 12,
    borderBottomWidth: 2,
    borderBottomColor: "#8f1230",
  },
  brand: {
    fontSize: 22,
    fontWeight: "bold",
    color: "#8f1230",
    marginBottom: 6,
  },
  heading: {
    fontSize: 15,
    marginBottom: 5,
  },
  muted: {
    fontSize: 9,
    color: "#64748b",
    marginTop: 4,
  },
  summary: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 16,
    padding: 10,
    backgroundColor: "#f1f5f9",
  },
  table: {
    width: "100%",
    marginTop: 8,
  },
  row: {
    flexDirection: "row",
    borderBottomWidth: 1,
    borderBottomColor: "#e2e8f0",
    paddingVertical: 8,
    alignItems: "center",
  },
  tableHeader: {
    backgroundColor: "#8f1230",
    color: "#ffffff",
    fontWeight: "bold",
  },
  cellName: {
    width: "32%",
    paddingHorizontal: 4,
  },
  cellPhone: {
    width: "23%",
    paddingHorizontal: 4,
  },
  cellAmount: {
    width: "22%",
    paddingHorizontal: 4,
    textAlign: "right",
  },
  cellBalance: {
    width: "23%",
    paddingHorizontal: 4,
    textAlign: "right",
  },
  total: {
    marginTop: 18,
    padding: 12,
    borderWidth: 1,
    borderColor: "#8f1230",
    fontSize: 12,
    fontWeight: "bold",
  },
  footer: {
    marginTop: 24,
    textAlign: "center",
    fontSize: 8,
    color: "#64748b",
  },
});

async function loadArabicFont() {
  const response = await fetch(
    "https://raw.githubusercontent.com/google/fonts/main/ofl/notonaskharabic/NotoNaskhArabic%5Bwght%5D.ttf",
    { cache: "force-cache" }
  );

  if (!response.ok) {
    throw new Error("تعذر تحميل الخط العربي لإنشاء PDF");
  }

  const buffer = Buffer.from(await response.arrayBuffer());

  Font.register({
    family: "NotoArabic",
    src: `data:font/ttf;base64,${buffer.toString("base64")}`,
  });
}

export async function POST(request: NextRequest) {
  try {
    const session = await authorize(request);

    if (!session) {
      return NextResponse.json(
        { success: false, message: "غير مصرح بالدخول" },
        { status: 403 }
      );
    }

    const body: { userIds?: unknown } = await request
  .json()
  .catch(() => ({}));

const requestedIds: string[] = Array.isArray(body.userIds)
  ? [
      ...new Set<string>(
        body.userIds
          .filter(
            (id: unknown): id is string =>
              typeof id === "string" && id.trim().length > 0
          )
          .map((id: string) => id.trim())
      ),
    ]
  : [];

    const { db } = session;

    const { data: week, error: weekError } = await db
      .from("weekly_periods")
      .select("id, start_at, end_at, is_closed")
      .eq("is_closed", true)
      .order("end_at", { ascending: false })
      .limit(1)
      .maybeSingle();

    if (weekError) throw new Error(weekError.message);

    if (!week) {
      return NextResponse.json(
        { success: false, message: "لا يوجد أسبوع مغلق لإعداد الكشف" },
        { status: 400 }
      );
    }

    const [
      { data: orders, error: ordersError },
      { data: activity, error: activityError },
      { data: settlements, error: settlementsError },
      { data: users, error: usersError },
    ] = await Promise.all([
      db.from("orders")
        .select("producer_id, consumer_id, commission_amount")
        .eq("processed_week_id", week.id)
        .eq("financially_processed", true)
        .neq("status", "cancelled"),

      db.from("weekly_user_activity")
        .select("user_id, floor_charged")
        .eq("week_id", week.id),

      db.from("transactions")
        .select("user_id")
        .eq("week_id", week.id)
        .eq("transaction_type", "previous_week_settlement"),

      db.from("users")
        .select("id, full_name, phone, balance, role, is_active, deleted_at")
        .eq("is_active", true)
        .is("deleted_at", null)
        .neq("role", "admin"),
    ]);

    if (ordersError) throw new Error(ordersError.message);
    if (activityError) throw new Error(activityError.message);
    if (settlementsError) throw new Error(settlementsError.message);
    if (usersError) throw new Error(usersError.message);

    const netByUser = new Map<string, number>();

    for (const order of orders ?? []) {
      const commission = Number(order.commission_amount || 0);

      if (order.producer_id) {
        const id = String(order.producer_id);
        netByUser.set(id, (netByUser.get(id) || 0) + commission);
      }

      if (order.consumer_id) {
        const id = String(order.consumer_id);
        netByUser.set(id, (netByUser.get(id) || 0) - commission);
      }
    }

    for (const row of activity ?? []) {
      if (row.floor_charged) {
        const id = String(row.user_id);
        netByUser.set(id, (netByUser.get(id) || 0) - 1);
      }
    }

    const settledIds = new Set(
      (settlements ?? []).map((row) => String(row.user_id))
    );

    let rows = (users ?? [])
      .map((user) => {
        const net = Number(
          (netByUser.get(String(user.id)) || 0).toFixed(2)
        );

        return {
          id: String(user.id),
          full_name: user.full_name || "بدون اسم",
          phone: user.phone || "-",
          amount: Number(Math.abs(net).toFixed(2)),
          previous_week_net: net,
          current_balance: Number(user.balance || 0),
        };
      })
      .filter((user) => user.previous_week_net < 0);

    // عند تحديد مستخدمين، نعرض المحددين فقط.
    if (requestedIds.length > 0) {
      const allowed = new Set(requestedIds);
      rows = rows.filter((user) => allowed.has(user.id));
    }

    // عند إنشاء كشف التسويات غير المسددة، لا نكرر من تمت تسويته.
    rows = rows.filter((user) => !settledIds.has(user.id));

    rows.sort((a, b) => b.amount - a.amount);

    await loadArabicFont();

    const total = Number(
      rows.reduce((sum, row) => sum + row.amount, 0).toFixed(2)
    );

    const pdf = React.createElement(
      Document,
      { title: "كشف تسويات خطك VIP" },
      React.createElement(
        Page,
        { size: "A4", style: styles.page },
        React.createElement(
          View,
          { style: styles.header },
          React.createElement(Text, { style: styles.brand }, "خطك VIP"),
          React.createElement(Text, { style: styles.heading }, "كشف التسويات الأسبوعية"),
          React.createElement(
            Text,
            { style: styles.muted },
            `الفترة: ${dateText(week.start_at)} - ${dateText(week.end_at)}`
          ),
          React.createElement(
            Text,
            { style: styles.muted },
            `تاريخ إنشاء الكشف: ${dateText(new Date().toISOString())}`
          )
        ),
        React.createElement(
          View,
          { style: styles.summary },
          React.createElement(Text, null, `عدد المستخدمين: ${rows.length}`),
          React.createElement(Text, null, `إجمالي المستحقات: ${money(total)}`)
        ),
        React.createElement(
          View,
          { style: styles.table },
          React.createElement(
            View,
            { style: [styles.row, styles.tableHeader] },
            React.createElement(Text, { style: styles.cellName }, "اسم المستخدم"),
            React.createElement(Text, { style: styles.cellPhone }, "رقم الهاتف"),
            React.createElement(Text, { style: styles.cellAmount }, "المستحق"),
            React.createElement(Text, { style: styles.cellBalance }, "الرصيد الحالي")
          ),
          ...rows.map((row) =>
            React.createElement(
              View,
              { style: styles.row, key: row.id },
              React.createElement(Text, { style: styles.cellName }, row.full_name),
              React.createElement(Text, { style: styles.cellPhone }, row.phone),
              React.createElement(Text, { style: styles.cellAmount }, money(row.amount)),
              React.createElement(
                Text,
                { style: styles.cellBalance },
                money(row.current_balance)
              )
            )
          )
        ),
        React.createElement(
          View,
          { style: styles.total },
          React.createElement(Text, null, `إجمالي المستحقات غير المسددة: ${money(total)}`)
        ),
        React.createElement(
          Text,
          { style: styles.footer },
          "خطك VIP — كشف مالي مولّد من النظام. يرجى مراجعة الإدارة عند وجود أي اختلاف."
        )
      )
    );

    const buffer = await renderToBuffer(pdf);

    const fileDate = new Intl.DateTimeFormat("en-CA", {
      timeZone: "Asia/Amman",
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
    }).format(new Date());

    return new Response(new Uint8Array(buffer), {
      status: 200,
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `attachment; filename="khattak-vip-settlements-${fileDate}.pdf"`,
        "Cache-Control": "no-store",
      },
    });
  } catch (error) {
    console.error("SETTLEMENT PDF ERROR:", error);

    return NextResponse.json(
      {
        success: false,
        message: error instanceof Error
          ? error.message
          : "تعذر إنشاء كشف PDF",
      },
      { status: 500 }
    );
  }
}
