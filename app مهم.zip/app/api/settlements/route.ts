
import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function getClients() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const publicKey = process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY;
  const secretKey = process.env.SUPABASE_SECRET_KEY;

  if (!url || !publicKey || !secretKey) {
    throw new Error("إعدادات Supabase غير مكتملة في .env.local");
  }

  return {
    auth: createClient(url, publicKey),
    db: createClient(url, secretKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false,
      },
    }),
  };
}

async function authorize(request: NextRequest) {
  const { auth, db } = getClients();
  const header = request.headers.get("authorization");

  if (!header?.startsWith("Bearer ")) return null;

  const token = header.slice(7).trim();
  if (!token) return null;

  const { data: authData, error: authError } =
    await auth.auth.getUser(token);

  if (authError || !authData.user) return null;

  const { data: admin, error } = await db
    .from("users")
    .select("id, role, is_active, deleted_at")
    .eq("id", authData.user.id)
    .eq("role", "admin")
    .eq("is_active", true)
    .is("deleted_at", null)
    .maybeSingle();

  if (error || !admin) return null;
  return { db, admin };
}

async function getPreviousWeek(db: ReturnType<typeof getClients>["db"]) {
  const { data, error } = await db
    .from("weekly_periods")
    .select("id, start_at, end_at, is_closed")
    .eq("is_closed", true)
    .order("end_at", { ascending: false })
    .limit(1)
    .maybeSingle();

  if (error) throw new Error(error.message);
  return data;
}

async function calculateWeek(db: ReturnType<typeof getClients>["db"], weekId: string) {
  const [
    { data: orders, error: ordersError },
    { data: activity, error: activityError },
    { data: settlements, error: settlementsError },
    { data: users, error: usersError },
  ] = await Promise.all([
    db.from("orders")
      .select("producer_id, consumer_id, commission_amount")
      .eq("processed_week_id", weekId)
      .eq("financially_processed", true)
      .neq("status", "cancelled"),

    db.from("weekly_user_activity")
      .select("user_id, floor_charged")
      .eq("week_id", weekId),

    db.from("transactions")
      .select("user_id")
      .eq("week_id", weekId)
      .eq("transaction_type", "previous_week_settlement"),

    db.from("users")
      .select("id, full_name, phone, role, balance, is_active")
      .is("deleted_at", null)
      .eq("is_active", true)
      .neq("role", "admin")
      .order("full_name", { ascending: true }),
  ]);

  if (ordersError) throw new Error(ordersError.message);
  if (activityError) throw new Error(activityError.message);
  if (settlementsError) throw new Error(settlementsError.message);
  if (usersError) throw new Error(usersError.message);

  const net = new Map<string, number>();

  for (const order of orders ?? []) {
    const commission = Number(order.commission_amount || 0);

    if (order.producer_id) {
      const id = String(order.producer_id);
      net.set(id, Number(((net.get(id) || 0) + commission).toFixed(2)));
    }

    if (order.consumer_id) {
      const id = String(order.consumer_id);
      net.set(id, Number(((net.get(id) || 0) - commission).toFixed(2)));
    }
  }

  for (const row of activity ?? []) {
    if (row.floor_charged) {
      const id = String(row.user_id);
      net.set(id, Number(((net.get(id) || 0) - 1).toFixed(2)));
    }
  }

  const settled = new Set(
    (settlements ?? []).map((row) => String(row.user_id))
  );

  const unpaidUsers = (users ?? [])
    .map((user) => {
      const previousWeekNet = Number((net.get(String(user.id)) || 0).toFixed(2));
      const amount = Number(Math.abs(previousWeekNet).toFixed(2));
      const currentBalance = Number(user.balance || 0);

      return {
        id: user.id,
        full_name: user.full_name || "بدون اسم",
        phone: user.phone || "-",
        amount,
        current_balance: currentBalance,
        previous_week_net: previousWeekNet,
        balance_after_settlement: Number(
          (currentBalance - previousWeekNet).toFixed(2)
        ),
        settlement_status: settled.has(String(user.id)) ? "مسدد" : "غير مسدد",
      };
    })
    .filter((user) => user.previous_week_net < 0 && user.settlement_status === "غير مسدد")
    .sort((a, b) => b.amount - a.amount);

  return {
    unpaidUsers,
    total: Number(
      unpaidUsers.reduce((sum, user) => sum + user.amount, 0).toFixed(2)
    ),
  };
}

export async function GET(request: NextRequest) {
  try {
    const session = await authorize(request);

    if (!session) {
      return NextResponse.json(
        { success: false, message: "غير مصرح بالدخول" },
        { status: 403 }
      );
    }

    const week = await getPreviousWeek(session.db);

    if (!week) {
      return NextResponse.json({
        success: true,
        previousWeek: null,
        users: [],
        total: 0,
      });
    }

    const result = await calculateWeek(session.db, week.id);

    return NextResponse.json({
      success: true,
      previousWeek: {
        id: week.id,
        start_at: week.start_at,
        end_at: week.end_at,
      },
      users: result.unpaidUsers,
      total: result.total,
    });
  } catch (error) {
    console.error("SETTLEMENT GET ERROR:", error);

    return NextResponse.json(
      {
        success: false,
        message: error instanceof Error ? error.message : "تعذر تحميل التسويات",
      },
      { status: 500 }
    );
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const session = await authorize(request);

    if (!session) {
      return NextResponse.json(
        { success: false, message: "غير مصرح بالدخول" },
        { status: 403 }
      );
    }

    const body = await request.json();
    const userId = String(body?.id || "").trim();

    if (!userId) {
      return NextResponse.json(
        { success: false, message: "معرف المستخدم مطلوب" },
        { status: 400 }
      );
    }

    const week = await getPreviousWeek(session.db);

    if (!week) {
      return NextResponse.json(
        { success: false, message: "لا يوجد أسبوع مغلق للتسوية" },
        { status: 400 }
      );
    }

    const { data: user, error: userError } = await session.db
      .from("users")
      .select("id, full_name, phone, role, balance, is_active, deleted_at")
      .eq("id", userId)
      .maybeSingle();

    if (userError) throw new Error(userError.message);

    if (!user || user.deleted_at || user.role === "admin") {
      return NextResponse.json(
        { success: false, message: "المستخدم غير موجود أو غير صالح للتسوية" },
        { status: 404 }
      );
    }

    const { data: existing, error: checkError } = await session.db
      .from("transactions")
      .select("id")
      .eq("user_id", userId)
      .eq("week_id", week.id)
      .eq("transaction_type", "previous_week_settlement")
      .limit(1)
      .maybeSingle();

    if (checkError) throw new Error(checkError.message);

    if (existing) {
      return NextResponse.json({
        success: true,
        alreadySettled: true,
        message: "تمت تسوية هذا الأسبوع سابقًا",
      });
    }

    const { unpaidUsers } = await calculateWeek(session.db, week.id);
    const due = unpaidUsers.find((item) => String(item.id) === userId);

    if (!due) {
      return NextResponse.json(
        { success: false, message: "لا توجد مستحقات غير مسددة لهذا المستخدم" },
        { status: 400 }
      );
    }

    const previousWeekNet = due.previous_week_net;
    const amount = due.amount;
    const balanceBefore = Number(user.balance || 0);
    const balanceAfter = Number((balanceBefore - previousWeekNet).toFixed(2));

    const { error: updateError } = await session.db
      .from("users")
      .update({
        balance: balanceAfter,
        updated_at: new Date().toISOString(),
      })
      .eq("id", userId);

    if (updateError) throw new Error(updateError.message);

    const { error: insertError } = await session.db
      .from("transactions")
      .insert({
        user_id: userId,
        transaction_type: "previous_week_settlement",
        amount,
        balance_before: balanceBefore,
        balance_after: balanceAfter,
        order_id: null,
        week_id: week.id,
        description: `تسوية مستحقات الأسبوع السابق (${week.start_at} - ${week.end_at})`,
        created_by: session.admin.id,
      });

    if (insertError) {
      // محاولة إعادة الرصيد السابق إذا فشل تسجيل الحركة المالية.
      const { error: rollbackError } = await session.db
        .from("users")
        .update({
          balance: balanceBefore,
          updated_at: new Date().toISOString(),
        })
        .eq("id", userId);

      if (rollbackError) {
        console.error("SETTLEMENT ROLLBACK ERROR:", rollbackError);
      }

      throw new Error(
        `تعذر تسجيل التسوية: ${insertError.message}` +
        (rollbackError ? "؛ تعذر أيضًا إرجاع الرصيد تلقائيًا، يرجى مراجعة الرصيد يدويًا." : "")
      );
    }

    return NextResponse.json({
      success: true,
      message: `تمت تسوية ${amount.toFixed(2)} د.أ بنجاح`,
      user: {
        id: user.id,
        full_name: user.full_name,
        phone: user.phone,
      },
      previousWeek: {
        id: week.id,
        start_at: week.start_at,
        end_at: week.end_at,
        net: previousWeekNet,
        debt: amount,
      },
      balance: {
        before: balanceBefore,
        after: balanceAfter,
      },
      settledAmount: amount,
      currentBalance: balanceAfter,
    });
  } catch (error) {
    console.error("SETTLEMENT PATCH ERROR:", error);

    return NextResponse.json(
      {
        success: false,
        message: error instanceof Error ? error.message : "تعذر تنفيذ التسوية",
      },
      { status: 500 }
    );
  }
}
