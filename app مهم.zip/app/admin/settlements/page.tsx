
"use client";

import { useCallback, useEffect, useState } from "react";
import { createClient } from "@supabase/supabase-js";
import {
  Home,
  Users,
  ClipboardList,
  Wallet,
  ArrowDownCircle,
  Activity,
  CalendarDays,
  Bell,
  Settings,
  LogOut,
  Menu,
  X,
  ShieldCheck,
  CheckCircle2,
  RefreshCw,
  Phone,
  Search,
  FileDown,
  AlertTriangle,
  Clock,
} from "lucide-react";

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY!
);

type SettlementUser = {
  id: string;
  user_id?: string;
  full_name: string;
  phone?: string | null;
  amount: number;
  settlement_amount?: number;
  current_balance: number;
  balance_after_settlement?: number;
  later_transactions_net?: number;
  is_preview?: boolean;
};

type PreviousWeek = {
  id: string;
  start_at: string;
  end_at: string;
  closed_at?: string | null;
};

type SettlementResponse = {
  success: boolean;
  message?: string;
  error?: string;
  users?: SettlementUser[];
  settlements?: SettlementUser[];
  previousWeek?: PreviousWeek | null;
  week?: PreviousWeek | null;
  total?: number;
  total_settlement_amount?: number;
  already_settled?: boolean;
  settlement?: {
    id: string;
    week_id: string;
    settled_at: string;
    status?: string;
  } | null;
};

function money(value: number | null | undefined) {
  return `${Number(value || 0).toFixed(2)} د.أ`;
}

function formatDate(value?: string | null) {
  if (!value) return "-";

  return new Intl.DateTimeFormat("ar-JO", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    timeZone: "Asia/Amman",
  }).format(new Date(value));
}

function formatDateTime(value?: string | null) {
  if (!value) return "-";

  return new Intl.DateTimeFormat("ar-JO", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    timeZone: "Asia/Amman",
  }).format(new Date(value));
}

function fileDate(value?: string | null) {
  if (!value) return "week";

  const date = new Date(value);

  return [
    date.getFullYear(),
    String(date.getMonth() + 1).padStart(2, "0"),
    String(date.getDate()).padStart(2, "0"),
  ].join("-");
}

export default function AdminSettlementsPage() {
  const [users, setUsers] = useState<SettlementUser[]>([]);
  const [previousWeek, setPreviousWeek] =
    useState<PreviousWeek | null>(null);

  const [total, setTotal] = useState(0);
  const [alreadySettled, setAlreadySettled] = useState(false);
  const [settlementId, setSettlementId] = useState<string | null>(
    null
  );
  const [settledAt, setSettledAt] = useState<string | null>(null);

  const [loading, setLoading] = useState(true);
  const [settling, setSettling] = useState(false);
  const [downloadingPdf, setDownloadingPdf] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  const [search, setSearch] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const token = useCallback(async () => {
    const {
      data: { session },
      error: sessionError,
    } = await supabase.auth.getSession();

    if (sessionError) {
      throw new Error("تعذر التحقق من جلسة تسجيل الدخول.");
    }

    return session?.access_token || null;
  }, []);

  const load = useCallback(async () => {
    try {
      setLoading(true);
      setError("");

      const accessToken = await token();

      if (!accessToken) {
        window.location.href = "/";
        return;
      }

      const response = await fetch("/api/admin/settlements", {
        method: "GET",
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
        cache: "no-store",
      });

      const data: SettlementResponse = await response.json();

      if (response.status === 401 || response.status === 403) {
        window.location.href = "/";
        return;
      }

      if (!response.ok || !data.success) {
        throw new Error(
          data.message || data.error || "تعذر تحميل التسويات."
        );
      }

      const week = data.week || data.previousWeek || null;
      const items = data.settlements || data.users || [];

      setPreviousWeek(week);
      setUsers(items);
      setTotal(
        Number(data.total_settlement_amount ?? data.total ?? 0)
      );
      setAlreadySettled(Boolean(data.already_settled));
      setSettlementId(data.settlement?.id || null);
      setSettledAt(data.settlement?.settled_at || null);
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : "حدث خطأ أثناء تحميل التسويات."
      );
    } finally {
      setLoading(false);
    }
  }, [token]);

  useEffect(() => {
    void load();
  }, [load]);

  async function settleWeek() {
    if (!previousWeek) {
      setError("لا يوجد أسبوع مغلق جاهز للتسوية.");
      return;
    }

    if (alreadySettled) {
      setError("هذا الأسبوع تمت تسويته مسبقًا.");
      return;
    }

    const confirmed = window.confirm(
      [
        "هل تريد تنفيذ التسوية الأسبوعية كاملة؟",
        "",
        `الأسبوع: ${formatDate(previousWeek.start_at)} إلى ${formatDate(previousWeek.end_at)}`,
        `عدد المستخدمين في الكشف: ${users.length}`,
        `إجمالي صافي التسوية المعروضة: ${money(total)}`,
        "",
        "سيتم تعديل الأرصدة وتسجيل الحركات المالية في قاعدة البيانات.",
        "لا يمكن التراجع عن العملية من هذه الصفحة.",
      ].join("\n")
    );

    if (!confirmed) return;

    try {
      setSettling(true);
      setError("");
      setSuccess("");

      const accessToken = await token();

      if (!accessToken) {
        window.location.href = "/";
        return;
      }

      const response = await fetch("/api/admin/settlements", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${accessToken}`,
        },
        body: JSON.stringify({
          weekId: previousWeek.id,
        }),
      });

      const data = await response.json();

      if (!response.ok || !data.success) {
        if (response.status === 409) {
          await load();
        }

        throw new Error(
          data.message || data.error || "فشل تنفيذ التسوية."
        );
      }

      setSuccess(
        data.message || "تم تنفيذ التسوية الأسبوعية بنجاح."
      );

      await load();
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : "حدث خطأ أثناء تنفيذ التسوية."
      );
    } finally {
      setSettling(false);
    }
  }

  async function downloadPdf() {
    if (!previousWeek) {
      setError("لا يوجد أسبوع لإنشاء الكشف.");
      return;
    }

    if (!alreadySettled || !settlementId) {
      setError("يجب تنفيذ التسوية أولًا قبل تحميل الكشف النهائي.");
      return;
    }

    if (users.length === 0) {
      setError("لا توجد كشوف محفوظة لهذا الأسبوع.");
      return;
    }

    try {
      setDownloadingPdf(true);
      setError("");
      setSuccess("");

      const accessToken = await token();

      if (!accessToken) {
        window.location.href = "/";
        return;
      }

      // قد يكون id هو معرف بند التسوية، لذلك نستخدم user_id
      // عند توفره لتجنب إرسال معرف بند بدل معرف المستخدم.
      const userIds = Array.from(
        new Set(
          users
            .map((user) => user.user_id || user.id)
            .filter(Boolean)
        )
      );

      const response = await fetch(
        "/api/admin/settlements/pdf",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${accessToken}`,
          },
          body: JSON.stringify({
            weekId: previousWeek.id,
            settlementId,
            userIds,
          }),
        }
      );

      if (!response.ok) {
        let message = "فشل إنشاء ملف PDF.";

        try {
          const data = await response.json();
          message = data.message || data.error || message;
        } catch {
          // قد يرجع الخادم استجابة غير JSON.
        }

        throw new Error(message);
      }

      const blob = await response.blob();

      if (!blob.size) {
        throw new Error("ملف PDF الذي رجع من الخادم فارغ.");
      }

      const objectUrl = window.URL.createObjectURL(blob);
      const link = document.createElement("a");

      link.href = objectUrl;
      link.download = `تسوية-الأسبوع-${fileDate(
        previousWeek.end_at
      )}.pdf`;

      document.body.appendChild(link);
      link.click();
      link.remove();

      window.setTimeout(() => {
        window.URL.revokeObjectURL(objectUrl);
      }, 1000);

      setSuccess("تم تنزيل ملف PDF.");
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : "تعذر تنزيل ملف PDF."
      );
    } finally {
      setDownloadingPdf(false);
    }
  }

  function go(path: string) {
    window.location.href = path;
  }

  async function logout() {
    await supabase.auth.signOut();
    window.location.href = "/";
  }

  const filteredUsers = users.filter((user) => {
    const query = search.trim().toLowerCase();

    if (!query) return true;

    return (
      (user.full_name || "").toLowerCase().includes(query) ||
      String(user.phone || "").toLowerCase().includes(query)
    );
  });

  function MenuItem({
    icon,
    title,
    active = false,
    onClick,
  }: {
    icon: React.ReactNode;
    title: string;
    active?: boolean;
    onClick: () => void;
  }) {
    return (
      <button
        type="button"
        onClick={onClick}
        className={`mb-1 flex w-full items-center gap-3 rounded-xl px-3 py-3 text-right text-sm font-bold transition ${
          active
            ? "bg-[#8f1230]/10 text-[#8f1230]"
            : "text-[#6f737a] hover:bg-[#faf9f7] hover:text-[#17181b]"
        }`}
      >
        {icon}
        <span>{title}</span>
      </button>
    );
  }

  function Sidebar() {
    return (
      <div className="flex h-full flex-col p-4">
        <div className="flex items-center justify-between border-b border-[#e6e3df] pb-4">
          <img
            src="/logo.svg"
            alt="خطك VIP"
            className="h-12 w-40 object-contain"
          />

          <button
            type="button"
            onClick={() => setMenuOpen(false)}
            className="rounded-xl bg-[#faf9f7] p-2 md:hidden"
            aria-label="إغلاق القائمة"
          >
            <X size={20} />
          </button>
        </div>

        <nav className="mt-5 flex-1">
          <MenuItem
            icon={<Home size={18} />}
            title="الرئيسية"
            onClick={() => go("/admin")}
          />
          <MenuItem
            icon={<Users size={18} />}
            title="المستخدمون"
            onClick={() => go("/admin/users")}
          />
          <MenuItem
            icon={<ClipboardList size={18} />}
            title="الطلبات"
            onClick={() => go("/admin/orders")}
          />
          <MenuItem
            icon={<Wallet size={18} />}
            title="الأرصدة"
            onClick={() => go("/admin/balances")}
          />
          <MenuItem
            icon={<CheckCircle2 size={18} />}
            title="تسويات الأسبوع"
            active
            onClick={() => go("/admin/settlements")}
          />
          <MenuItem
            icon={<ArrowDownCircle size={18} />}
            title="طلبات السحب"
            onClick={() => go("/admin/withdrawals")}
          />
          <MenuItem
            icon={<Activity size={18} />}
            title="الحركات المالية"
            onClick={() => go("/admin/transactions")}
          />
          <MenuItem
            icon={<CalendarDays size={18} />}
            title="الأسابيع"
            onClick={() => go("/admin/weeks")}
          />
          <MenuItem
            icon={<Bell size={18} />}
            title="الإشعارات"
            onClick={() => go("/admin/notifications")}
          />
          <MenuItem
            icon={<Settings size={18} />}
            title="الإعدادات"
            onClick={() => go("/admin/settings")}
          />
        </nav>

        <button
          type="button"
          onClick={logout}
          className="flex items-center gap-3 rounded-xl px-3 py-3 text-sm font-bold text-red-600 hover:bg-red-50"
        >
          <LogOut size={18} />
          تسجيل الخروج
        </button>
      </div>
    );
  }

  return (
    <main
      dir="rtl"
      className="min-h-screen bg-[#f6f3ef] text-[#17181b]"
    >
      {menuOpen && (
        <button
          type="button"
          aria-label="إغلاق القائمة"
          className="fixed inset-0 z-40 bg-black/50 md:hidden"
          onClick={() => setMenuOpen(false)}
        />
      )}

      <aside
        className={`fixed right-0 top-0 z-50 h-full w-[84%] max-w-[350px] border-l border-[#e6e3df] bg-white shadow-2xl transition-transform md:hidden ${
          menuOpen ? "translate-x-0" : "translate-x-full"
        }`}
      >
        <Sidebar />
      </aside>

      <header className="sticky top-0 z-30 border-b border-[#e6e3df] bg-white/95 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4 sm:px-6">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setMenuOpen(true)}
              className="rounded-xl bg-[#faf9f7] p-2 md:hidden"
              aria-label="فتح القائمة"
            >
              <Menu size={20} />
            </button>

            <img
              src="/logo.svg"
              alt="خطك VIP"
              className="h-11 w-36 object-contain"
            />
          </div>

          <div className="hidden items-center gap-2 text-sm font-bold text-[#6f737a] sm:flex">
            <ShieldCheck size={17} className="text-[#8f1230]" />
            إدارة التسويات الأسبوعية
          </div>
        </div>
      </header>

      <div className="mx-auto flex max-w-7xl gap-6 px-4 py-6 sm:px-6">
        <aside className="hidden w-60 shrink-0 md:block">
          <div className="sticky top-24 rounded-2xl border border-[#e6e3df] bg-white">
            <Sidebar />
          </div>
        </aside>

        <section className="min-w-0 flex-1">
          <div className="mb-6 flex flex-col gap-4">
            <div className="flex flex-col gap-4 xl:flex-row xl:items-end xl:justify-between">
              <div>
                <p className="text-xs font-black text-[#8f1230]">
                  الإدارة المالية
                </p>

                <h1 className="mt-1 text-2xl font-black sm:text-3xl">
                  التسويات الأسبوعية
                </h1>

                <p className="mt-2 max-w-2xl text-sm leading-6 text-[#6f737a]">
                  معاينة المستحقات المسجلة، وتنفيذ التسوية للأسبوع المغلق
                  كاملًا، ثم تحميل كشف PDF المحفوظ.
                </p>
              </div>

              <div className="flex flex-col gap-2 sm:flex-row">
                <button
                  type="button"
                  onClick={downloadPdf}
                  disabled={
                    loading ||
                    downloadingPdf ||
                    !alreadySettled ||
                    users.length === 0
                  }
                  className="inline-flex items-center justify-center gap-2 rounded-xl border border-[#e6e3df] bg-white px-4 py-3 text-sm font-black transition hover:bg-[#faf9f7] disabled:cursor-not-allowed disabled:opacity-50"
                >
                  {downloadingPdf ? (
                    <RefreshCw size={17} className="animate-spin" />
                  ) : (
                    <FileDown size={17} />
                  )}
                  {downloadingPdf
                    ? "جاري تجهيز PDF..."
                    : "تحميل كشف PDF"}
                </button>

                <button
                  type="button"
                  onClick={() => void load()}
                  disabled={loading || settling}
                  className="inline-flex items-center justify-center gap-2 rounded-xl border border-[#e6e3df] bg-white px-4 py-3 text-sm font-black transition hover:bg-[#faf9f7] disabled:opacity-50"
                >
                  <RefreshCw
                    size={17}
                    className={loading ? "animate-spin" : ""}
                  />
                  تحديث
                </button>
              </div>
            </div>
          </div>

          {error && (
            <div className="mb-5 flex items-start gap-3 rounded-2xl border border-red-200 bg-red-50 p-4 text-sm font-bold leading-6 text-red-700">
              <AlertTriangle size={20} className="mt-0.5 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {success && (
            <div className="mb-5 flex items-start gap-3 rounded-2xl border border-emerald-200 bg-emerald-50 p-4 text-sm font-bold leading-6 text-emerald-700">
              <CheckCircle2 size={20} className="mt-0.5 shrink-0" />
              <span>{success}</span>
            </div>
          )}

          {loading ? (
            <div className="rounded-2xl border border-[#e6e3df] bg-white p-12 text-center">
              <RefreshCw
                size={26}
                className="mx-auto animate-spin text-[#8f1230]"
              />
              <p className="mt-4 text-sm font-bold text-[#6f737a]">
                جاري تحميل بيانات التسوية...
              </p>
            </div>
          ) : !previousWeek ? (
            <div className="rounded-2xl border border-[#e6e3df] bg-white p-10 text-center">
              <CalendarDays
                size={32}
                className="mx-auto text-[#8f1230]"
              />
              <h2 className="mt-4 text-lg font-black">
                لا يوجد أسبوع مغلق
              </h2>
              <p className="mt-2 text-sm text-[#6f737a]">
                ستظهر التسوية هنا بعد إغلاق الأسبوع في النظام.
              </p>
            </div>
          ) : (
            <>
              <div className="mb-5 grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
                <div className="rounded-2xl border border-[#e6e3df] bg-white p-5">
                  <div className="flex items-center gap-2 text-xs font-bold text-[#6f737a]">
                    <CalendarDays size={16} />
                    الأسبوع المستهدف
                  </div>
                  <p className="mt-3 text-lg font-black">
                    {formatDate(previousWeek.start_at)}
                  </p>
                  <p className="mt-1 text-sm text-[#6f737a]">
                    إلى {formatDate(previousWeek.end_at)}
                  </p>
                </div>

                <div className="rounded-2xl border border-[#e6e3df] bg-white p-5">
                  <div className="flex items-center gap-2 text-xs font-bold text-[#6f737a]">
                    <Users size={16} />
                    عدد كشوف المستخدمين
                  </div>
                  <p className="mt-3 text-3xl font-black">
                    {users.length}
                  </p>
                  <p className="mt-1 text-xs text-[#6f737a]">
                    {alreadySettled
                      ? "كشوف محفوظة في قاعدة البيانات"
                      : "مستخدمون ضمن المعاينة"}
                  </p>
                </div>

                <div className="rounded-2xl border border-[#e6e3df] bg-white p-5 sm:col-span-2 xl:col-span-1">
                  <div className="flex items-center gap-2 text-xs font-bold text-[#6f737a]">
                    <Wallet size={16} />
                    إجمالي صافي التسوية
                  </div>
                  <p className="mt-3 text-3xl font-black text-[#8f1230]">
                    {money(total)}
                  </p>
                  <p className="mt-1 text-xs text-[#6f737a]">
                    وفق بيانات التسوية المعروضة
                  </p>
                </div>
              </div>

              <div
                className={`mb-5 rounded-2xl border p-4 ${
                  alreadySettled
                    ? "border-emerald-200 bg-emerald-50"
                    : "border-amber-200 bg-amber-50"
                }`}
              >
                <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                  <div className="flex items-start gap-3">
                    {alreadySettled ? (
                      <CheckCircle2
                        size={22}
                        className="mt-0.5 shrink-0 text-emerald-700"
                      />
                    ) : (
                      <Clock
                        size={22}
                        className="mt-0.5 shrink-0 text-amber-700"
                      />
                    )}

                    <div>
                      <p
                        className={`font-black ${
                          alreadySettled
                            ? "text-emerald-800"
                            : "text-amber-900"
                        }`}
                      >
                        {alreadySettled
                          ? "تم تنفيذ التسوية"
                          : "معاينة قبل تنفيذ التسوية"}
                      </p>

                      <p
                        className={`mt-1 text-sm leading-6 ${
                          alreadySettled
                            ? "text-emerald-800"
                            : "text-amber-900"
                        }`}
                      >
                        {alreadySettled
                          ? `التسوية محفوظة${settledAt ? ` بتاريخ ${formatDateTime(settledAt)}` : ""}. لن يظهر زر تنفيذها مرة أخرى.`
                          : "المبالغ المعروضة للمعاينة فقط، ولم يتم تغيير الأرصدة بعد. تأكد من صحة البيانات قبل التنفيذ."}
                      </p>

                      {settlementId && (
                        <p className="mt-2 break-all text-xs text-[#6f737a]">
                          رقم التسوية: {settlementId}
                        </p>
                      )}
                    </div>
                  </div>

                  {!alreadySettled && (
                    <button
                      type="button"
                      onClick={settleWeek}
                      disabled={settling || loading}
                      className="inline-flex shrink-0 items-center justify-center gap-2 rounded-xl bg-[#8f1230] px-5 py-3 text-sm font-black text-white transition hover:bg-[#741026] disabled:cursor-not-allowed disabled:opacity-50"
                    >
                      {settling ? (
                        <>
                          <RefreshCw
                            size={17}
                            className="animate-spin"
                          />
                          جاري تنفيذ التسوية...
                        </>
                      ) : (
                        <>
                          <CheckCircle2 size={17} />
                          تنفيذ تسوية الأسبوع كاملًا
                        </>
                      )}
                    </button>
                  )}
                </div>
              </div>

              <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <h2 className="text-lg font-black">
                  تفاصيل المستخدمين
                </h2>

                <div className="relative w-full sm:max-w-sm">
                  <Search
                    size={18}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-[#6f737a]"
                  />
                  <input
                    type="text"
                    value={search}
                    onChange={(event) => setSearch(event.target.value)}
                    placeholder="بحث بالاسم أو الهاتف..."
                    className="w-full rounded-xl border border-[#e6e3df] bg-white py-3 pl-4 pr-10 text-sm font-bold outline-none focus:border-[#8f1230] focus:ring-2 focus:ring-[#8f1230]/10"
                  />
                  {search && (
                    <button
                      type="button"
                      onClick={() => setSearch("")}
                      aria-label="مسح البحث"
                      className="absolute left-3 top-1/2 -translate-y-1/2 rounded-lg p-1 text-[#6f737a]"
                    >
                      <X size={15} />
                    </button>
                  )}
                </div>
              </div>

              {users.length === 0 ? (
                <div className="rounded-2xl border border-[#e6e3df] bg-white p-10 text-center">
                  <Users
                    size={30}
                    className="mx-auto text-[#6f737a]"
                  />
                  <p className="mt-3 font-black">
                    لا توجد كشوف مستخدمين لهذا الأسبوع
                  </p>
                </div>
              ) : filteredUsers.length === 0 ? (
                <div className="rounded-2xl border border-[#e6e3df] bg-white p-10 text-center">
                  <Search
                    size={28}
                    className="mx-auto text-[#6f737a]"
                  />
                  <p className="mt-3 font-black">
                    لا توجد نتائج مطابقة للبحث
                  </p>
                </div>
              ) : (
                <div className="overflow-hidden rounded-2xl border border-[#e6e3df] bg-white">
                  <div className="hidden grid-cols-4 gap-4 border-b border-[#e6e3df] bg-[#faf9f7] px-5 py-4 text-xs font-black text-[#6f737a] lg:grid">
                    <span className="col-span-2">المستخدم</span>
                    <span>الرصيد قبل التسوية</span>
                    <span>مبلغ التسوية</span>
                  </div>

                  {filteredUsers.map((user) => {
                    const amount = Number(
                      user.settlement_amount ?? user.amount ?? 0
                    );

                    return (
                      <div
                        key={`${user.user_id || user.id}`}
                        className="grid gap-4 border-b border-[#e6e3df] px-4 py-5 last:border-0 sm:px-5 lg:grid-cols-4 lg:items-center"
                      >
                        <div className="flex min-w-0 items-center gap-3 lg:col-span-2">
                          <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-[#8f1230]/10 font-black text-[#8f1230]">
                            {(user.full_name || "مستخدم")
                              .trim()
                              .split(/\s+/)
                              .slice(0, 2)
                              .map((part) => part[0] || "")
                              .join("")}
                          </div>

                          <div className="min-w-0">
                            <p className="break-words font-black">
                              {user.full_name || "مستخدم"}
                            </p>

                            {user.phone && (
                              <p className="mt-1 flex items-center gap-1 text-xs text-[#6f737a]">
                                <Phone size={13} />
                                <span dir="ltr">{user.phone}</span>
                              </p>
                            )}
                          </div>
                        </div>

                        <div>
                          <p className="text-xs font-bold text-[#6f737a] lg:hidden">
                            الرصيد قبل التسوية
                          </p>
                          <p className="mt-1 font-black">
                            {money(user.current_balance)}
                          </p>
                        </div>

                        <div>
                          <p className="text-xs font-bold text-[#6f737a] lg:hidden">
                            مبلغ التسوية
                          </p>
                          <p
                            className={`mt-1 text-lg font-black ${
                              amount < 0
                                ? "text-red-600"
                                : amount > 0
                                  ? "text-emerald-700"
                                  : "text-[#6f737a]"
                            }`}
                          >
                            {money(amount)}
                          </p>

                          {user.balance_after_settlement !== undefined && (
                            <p className="mt-1 text-xs text-[#6f737a]">
                              الرصيد بعد التسوية:{" "}
                              {money(user.balance_after_settlement)}
                            </p>
                          )}

                          {user.later_transactions_net !== undefined && (
                            <p className="mt-1 text-xs text-[#6f737a]">
                              صافي الحركات اللاحقة:{" "}
                              {money(user.later_transactions_net)}
                            </p>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}

              <p className="mt-4 text-xs leading-6 text-[#6f737a]">
                ملاحظة: تنفيذ التسوية يتم للأسبوع كاملًا من خلال قاعدة
                البيانات، وليس عبر تسوية مستقلة لكل مستخدم. تنزيل PDF
                النهائي متاح بعد حفظ التسوية.
              </p>
            </>
          )}
        </section>
      </div>
    </main>
  );
}
