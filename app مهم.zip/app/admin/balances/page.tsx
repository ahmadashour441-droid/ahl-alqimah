
"use client";

import { useEffect, useMemo, useState } from "react";
import { createClient } from "@supabase/supabase-js";
import {
  Home,
  Users,
  ClipboardList,
  Wallet,
  ArrowDownCircle,
  Activity,
  CalendarDays,
  Bell,
  Settings,
  LogOut,
  Menu,
  X,
  Plus,
  Pencil,
  RotateCcw,
  Search,
  Save,
  ShieldCheck,
  CheckCircle2,
} from "lucide-react";

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY!
);

type User = {
  id: string;
  full_name: string;
  phone: string;
  role: "user" | "admin";
  balance: number;
  is_active: boolean;
};

export default function AdminBalancesPage() {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [search, setSearch] = useState("");
  const [menuOpen, setMenuOpen] = useState(false);
  const [selected, setSelected] = useState<User | null>(null);
  const [amount, setAmount] = useState("");
  const [mode, setMode] = useState<"add" | "set" | "zero">("add");

  async function token() {
    const {
      data: { session },
    } = await supabase.auth.getSession();

    return session?.access_token || null;
  }

  async function load() {
    try {
      setLoading(true);
      setError("");

      const t = await token();

      if (!t) {
        window.location.href = "/";
        return;
      }

      const r = await fetch("/api/admin/users", {
        headers: {
          Authorization: `Bearer ${t}`,
        },
        cache: "no-store",
      });

      const data = await r.json();

      if (!r.ok || !data.success) {
        throw new Error(data.message || "تعذر تحميل المستخدمين");
      }

      setUsers(data.users || []);
    } catch (e: any) {
      setError(e.message || "حدث خطأ أثناء تحميل الأرصدة");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  async function saveBalance() {
    if (!selected) return;

    const current = Number(selected.balance || 0);
    let next = current;

    if (mode === "zero") {
      next = 0;
    } else {
      const n = Number(amount);

      if (!Number.isFinite(n)) {
        setError("أدخل مبلغًا صحيحًا");
        return;
      }

      next = mode === "add" ? current + n : n;
    }

    try {
      setSaving(true);
      setError("");
      setSuccess("");

      const t = await token();

      if (!t) {
        window.location.href = "/";
        return;
      }

      const r = await fetch("/api/admin/users", {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${t}`,
        },
        body: JSON.stringify({
          id: selected.id,
          full_name: selected.full_name,
          phone: selected.phone,
          role: selected.role,
          is_active: selected.is_active,
          balance: Number(next.toFixed(2)),
        }),
      });

      const data = await r.json();

      if (!r.ok || !data.success) {
        throw new Error(data.message || "تعذر تحديث الرصيد");
      }

      setSuccess(
        mode === "zero"
          ? "تم تصفير الرصيد الحالي بنجاح"
          : "تم تحديث الرصيد بنجاح"
      );

      setSelected(null);
      setAmount("");
      await load();
    } catch (e: any) {
      setError(e.message || "تعذر تحديث الرصيد");
    } finally {
      setSaving(false);
    }
  }

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();

    if (!q) return users;

    return users.filter((u) =>
      [u.full_name, u.phone, u.role, String(u.balance)].some((v) =>
        String(v || "").toLowerCase().includes(q)
      )
    );
  }, [users, search]);

  const go = (path: string) => {
    window.location.href = path;
  };

  const money = (n: number) => `${Number(n || 0).toFixed(2)} د.أ`;

  const MenuItem = ({
    icon,
    title,
    active,
    onClick,
  }: {
    icon: React.ReactNode;
    title: string;
    active?: boolean;
    onClick: () => void;
  }) => (
    <button
      onClick={onClick}
      className={`mb-1 flex w-full items-center gap-3 rounded-xl px-3 py-3 text-right text-sm font-bold transition ${
        active
          ? "bg-[#8f1230]/15 text-[#8f1230]"
          : "text-[#6f737a]/60 hover:bg-[#faf9f7] hover:text-[#17181b]"
      }`}
    >
      {icon}
      <span>{title}</span>
    </button>
  );

  return (
    <main dir="rtl" className="min-h-screen bg-[#f6f3ef] text-[#17181b]">
      {menuOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/60"
          onClick={() => setMenuOpen(false)}
        />
      )}

      {/* Mobile Sidebar */}
      <aside
        className={`fixed right-0 top-0 z-50 h-full w-[84%] max-w-[350px] border-l border-[#e6e3df] bg-white shadow-2xl transition-transform ${
          menuOpen ? "translate-x-0" : "translate-x-full"
        }`}
      >
        <div className="flex h-full flex-col p-4">
          <div className="flex items-center justify-between border-b border-[#e6e3df] pb-4">
            <img
              src="/logo.svg"
              alt="خطك VIP"
              className="h-14 w-44 object-contain"
            />

            <button
              onClick={() => setMenuOpen(false)}
              className="rounded-xl bg-[#faf9f7] p-2 text-[#6f737a]/60"
            >
              <X size={20} />
            </button>
          </div>

          <div className="mt-5 flex-1">
            <MenuItem icon={<Home size={18} />} title="الرئيسية" onClick={() => go("/admin")} />
            <MenuItem icon={<Users size={18} />} title="المستخدمون" onClick={() => go("/admin/users")} />
            <MenuItem
              icon={<ClipboardList size={18} />}
              title="الطلبات"
              onClick={() => go("/admin/orders")}
            />
            <MenuItem
              icon={<Wallet size={18} />}
              title="الأرصدة"
              active
              onClick={() => go("/admin/balances")}
            />
            <MenuItem
              icon={<CheckCircle2 size={18} />}
              title="تسويات الأسبوع السابق"
              onClick={() => go("/admin/settlements")}
            />
            <MenuItem
              icon={<ArrowDownCircle size={18} />}
              title="طلبات السحب"
              onClick={() => go("/admin/withdrawals")}
            />
            <MenuItem
              icon={<Activity size={18} />}
              title="الحركات المالية"
              onClick={() => go("/admin/transactions")}
            />
            <MenuItem
              icon={<CalendarDays size={18} />}
              title="الأسابيع"
              onClick={() => go("/admin/weeks")}
            />
            <MenuItem
              icon={<Bell size={18} />}
              title="الإشعارات"
              onClick={() => go("/admin/notifications")}
            />
            <MenuItem
              icon={<Settings size={18} />}
              title="الإعدادات"
              onClick={() => go("/admin/settings")}
            />
          </div>

          <button
            onClick={async () => {
              await supabase.auth.signOut();
              go("/");
            }}
            className="flex items-center gap-3 rounded-xl px-3 py-3 text-sm font-bold text-red-500"
          >
            <LogOut size={18} />
            تسجيل الخروج
          </button>
        </div>
      </aside>

      {/* Header */}
      <header className="sticky top-0 z-30 border-b border-[#e6e3df] bg-white/95 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4 sm:px-6">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setMenuOpen(true)}
              className="rounded-xl bg-[#faf9f7] p-2 md:hidden"
            >
              <Menu size={20} />
            </button>

            <img
              src="/logo.svg"
              alt="خطك VIP"
              className="h-11 w-36 object-contain"
            />
          </div>

          <div className="hidden items-center gap-2 text-sm text-[#6f737a]/50 md:flex">
            <ShieldCheck size={17} className="text-[#8f1230]" />
            إدارة الأرصدة
          </div>
        </div>
      </header>

      <div className="mx-auto flex max-w-7xl gap-6 px-4 py-6 sm:px-6">
        {/* Desktop Sidebar */}
        <aside className="hidden w-60 shrink-0 md:block">
          <div className="sticky top-24 rounded-2xl border border-[#e6e3df] bg-white p-3">
            <MenuItem icon={<Home size={18} />} title="الرئيسية" onClick={() => go("/admin")} />
            <MenuItem icon={<Users size={18} />} title="المستخدمون" onClick={() => go("/admin/users")} />
            <MenuItem
              icon={<ClipboardList size={18} />}
              title="الطلبات"
              onClick={() => go("/admin/orders")}
            />
            <MenuItem
              icon={<Wallet size={18} />}
              title="الأرصدة"
              active
              onClick={() => go("/admin/balances")}
            />
            <MenuItem
              icon={<CheckCircle2 size={18} />}
              title="تسويات الأسبوع السابق"
              onClick={() => go("/admin/settlements")}
            />
            <MenuItem
              icon={<ArrowDownCircle size={18} />}
              title="طلبات السحب"
              onClick={() => go("/admin/withdrawals")}
            />
            <MenuItem
              icon={<Activity size={18} />}
              title="الحركات المالية"
              onClick={() => go("/admin/transactions")}
            />
            <MenuItem
              icon={<CalendarDays size={18} />}
              title="الأسابيع"
              onClick={() => go("/admin/weeks")}
            />
            <MenuItem
              icon={<Bell size={18} />}
              title="الإشعارات"
              onClick={() => go("/admin/notifications")}
            />
            <MenuItem
              icon={<Settings size={18} />}
              title="الإعدادات"
              onClick={() => go("/admin/settings")}
            />
          </div>
        </aside>

        {/* Main Content */}
        <section className="min-w-0 flex-1">
          <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <p className="text-xs font-bold text-[#8f1230]">الإدارة</p>
              <h1 className="mt-1 text-2xl font-black">الأرصدة</h1>
              <p className="mt-1 text-sm text-[#6f737a]/60">
                تعديل الأرصدة وتصفيرها ومراجعتها
              </p>
            </div>
          </div>

          {error && (
            <div className="mb-4 rounded-xl border border-red-200 bg-red-50 p-3 text-sm font-bold text-red-700">
              {error}
            </div>
          )}

          {success && (
            <div className="mb-4 rounded-xl border border-emerald-200 bg-emerald-50 p-3 text-sm font-bold text-emerald-700">
              {success}
            </div>
          )}

          {/* Search */}
          <div className="mb-4 flex items-center gap-2 rounded-2xl border border-[#e6e3df] bg-white p-3">
            <Search size={18} className="text-[#6f737a]/50" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="ابحث بالاسم أو رقم الهاتف أو الرصيد"
              className="w-full bg-transparent text-sm outline-none"
            />
          </div>

          {/* Users */}
          {loading ? (
            <div className="rounded-2xl border border-[#e6e3df] bg-white p-10 text-center text-sm font-bold text-[#6f737a]/60">
              جاري تحميل الأرصدة...
            </div>
          ) : (
            <div className="overflow-hidden rounded-2xl border border-[#e6e3df] bg-white">
              <div className="hidden grid-cols-6 gap-3 border-b border-[#e6e3df] px-5 py-4 text-xs font-bold text-[#6f737a]/60 md:grid">
                <span>#</span>
                <span className="col-span-2">المستخدم</span>
                <span>الهاتف</span>
                <span>الرصيد</span>
                <span>الإجراءات</span>
              </div>

              {filtered.map((u, i) => (
                <div
                  key={u.id}
                  className="grid gap-3 border-b border-[#e6e3df] px-4 py-4 last:border-0 md:grid-cols-6 md:items-center md:px-5"
                >
                  <span className="text-xs text-[#6f737a]/50">{i + 1}</span>

                  <div className="md:col-span-2">
                    <p className="font-bold">{u.full_name}</p>
                    <p className="text-[11px] text-[#6f737a]/50">
                      {u.role === "admin" ? "أدمن" : "مستخدم"}
                    </p>
                  </div>

                  <span className="text-xs text-[#6f737a]/60">{u.phone}</span>

                  <span
                    className={`font-black ${
                      u.balance < 0
                        ? "text-red-500"
                        : u.balance > 0
                        ? "text-[#8f1230]"
                        : "text-[#6f737a]/60"
                    }`}
                  >
                    {money(u.balance)}
                  </span>

                  <div className="flex flex-wrap gap-2">
                    <button
                      onClick={() => {
                        setSelected(u);
                        setMode("set");
                        setAmount(String(u.balance));
                        setError("");
                        setSuccess("");
                      }}
                      className="inline-flex items-center gap-1 rounded-lg bg-[#faf9f7] px-3 py-2 text-xs font-bold"
                    >
                      <Pencil size={14} />
                      تعديل
                    </button>

                    <button
                      onClick={() => {
                        setSelected(u);
                        setMode("zero");
                        setAmount("0");
                        setError("");
                        setSuccess("");
                      }}
                      className="inline-flex items-center gap-1 rounded-lg bg-red-50 px-3 py-2 text-xs font-bold text-red-600"
                    >
                      <RotateCcw size={14} />
                      تصفير
                    </button>
                  </div>
                </div>
              ))}

              {filtered.length === 0 && (
                <div className="p-10 text-center text-sm text-[#6f737a]/60">
                  لا توجد نتائج.
                </div>
              )}
            </div>
          )}
        </section>
      </div>

      {/* Balance Modal */}
      {selected && (
        <div
          className="fixed inset-0 z-[70] flex items-center justify-center bg-black/45 p-4"
          onClick={() => !saving && setSelected(null)}
        >
          <div
            className="w-full max-w-md rounded-3xl border border-[#e6e3df] bg-white p-5 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="mb-5 flex items-center justify-between">
              <div>
                <h2 className="text-lg font-black">تعديل الرصيد</h2>
                <p className="mt-1 text-xs text-[#6f737a]/60">
                  {selected.full_name}
                </p>
              </div>

              <button
                onClick={() => setSelected(null)}
                className="rounded-xl bg-[#faf9f7] p-2"
              >
                <X size={18} />
              </button>
            </div>

            <div className="mb-4 rounded-2xl bg-[#faf9f7] p-4">
              <p className="text-xs text-[#6f737a]/60">الرصيد الحالي</p>
              <p className="mt-1 text-2xl font-black text-[#8f1230]">
                {money(selected.balance)}
              </p>
            </div>

            <div className="mb-4 grid grid-cols-2 gap-2">
              <button
                onClick={() => setMode("add")}
                className={`rounded-xl px-3 py-3 text-xs font-bold ${
                  mode === "add"
                    ? "bg-[#8f1230] text-white"
                    : "bg-[#faf9f7] text-[#6f737a]/60"
                }`}
              >
                إضافة مبلغ
              </button>

              <button
                onClick={() => setMode("set")}
                className={`rounded-xl px-3 py-3 text-xs font-bold ${
                  mode === "set"
                    ? "bg-[#8f1230] text-white"
                    : "bg-[#faf9f7] text-[#6f737a]/60"
                }`}
              >
                تحديد الرصيد
              </button>
            </div>

            <label className="mb-2 block text-xs font-bold text-[#6f737a]/60">
              {mode === "add"
                ? "المبلغ المراد إضافته"
                : mode === "set"
                ? "الرصيد الجديد"
                : "تصفير الرصيد الحالي"}
            </label>

            {mode !== "zero" ? (
              <input
                type="number"
                step="0.01"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0.00"
                className="mb-4 w-full rounded-xl border border-[#e6e3df] bg-[#fffaf0] px-4 py-3 text-lg font-bold outline-none focus:border-[#8f1230]"
              />
            ) : (
              <div className="mb-4 rounded-xl border border-red-100 bg-red-50 px-4 py-3 text-sm font-bold text-red-700">
                سيتم تصفير الرصيد الحالي فقط. هذه العملية منفصلة عن تسوية الأسبوع السابق.
              </div>
            )}

            <button
              onClick={saveBalance}
              disabled={saving}
              className="flex w-full items-center justify-center gap-2 rounded-xl bg-[#8f1230] px-4 py-3 font-black text-white disabled:opacity-50"
            >
              <Save size={17} />
              {saving
                ? "جاري الحفظ..."
                : mode === "zero"
                ? "تصفير الرصيد الحالي"
                : "حفظ الرصيد"}
            </button>
          </div>
        </div>
      )}
    </main>
  );
}
