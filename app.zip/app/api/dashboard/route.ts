import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";
import crypto from "crypto";

function createSupabaseAdmin() {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SECRET_KEY!
  );
}

/* =====================================================
   التحقق من الـ Custom Session
===================================================== */

function verifySession(token: string) {
  try {
    const secret = process.env.AUTH_SESSION_SECRET;

    if (!secret) {
      throw new Error(
        "AUTH_SESSION_SECRET غير موجود في .env.local"
      );
    }

    const parts = token.split(".");

    if (parts.length !== 2) {
      return null;
    }

    const [encodedPayload, signature] = parts;

    const expectedSignature = crypto
      .createHmac("sha256", secret)
      .update(encodedPayload)
      .digest("base64url");

    const signaturesMatch = crypto.timingSafeEqual(
      Buffer.from(signature),
      Buffer.from(expectedSignature)
    );

    if (!signaturesMatch) {
      return null;
    }

    const payload = JSON.parse(
      Buffer.from(encodedPayload, "base64url").toString("utf8")
    );

    if (!payload.userId || !payload.exp) {
      return null;
    }

    if (Date.now() > Number(payload.exp)) {
      return null;
    }

    return {
      userId: String(payload.userId),
      role: String(payload.role || "user"),
    };
  } catch (error) {
    console.error("SESSION VERIFY ERROR:", error);
    return null;
  }
}

export async function GET(request: Request) {
  try {
    /* =====================================================
       التحقق من جلسة المستخدم
    ===================================================== */

    const authHeader = request.headers.get("authorization");

    if (!authHeader?.startsWith("Bearer ")) {
      return NextResponse.json(
        {
          error: "غير مصرح",
        },
        {
          status: 401,
        }
      );
    }

    const token = authHeader.substring(7).trim();

    const session = verifySession(token);

    if (!session) {
      return NextResponse.json(
        {
          error: "جلسة الدخول غير صالحة",
        },
        {
          status: 401,
        }
      );
    }

    const userId = session.userId;

    /* =====================================================
       Admin Client
    ===================================================== */

    const supabaseAdmin = createSupabaseAdmin();

    /* =====================================================
       بيانات المستخدم
    ===================================================== */

    const {
      data: user,
      error: userError,
    } = await supabaseAdmin
      .from("users")
      .select(
        "id, full_name, phone, role, balance, is_active"
      )
      .eq("id", userId)
      .is("deleted_at", null)
      .maybeSingle();

    if (userError) {
      console.error(
        "DASHBOARD USER ERROR:",
        userError
      );

      return NextResponse.json(
        {
          error: "تعذر تحميل بيانات المستخدم",
          details: userError.message,
        },
        {
          status: 500,
        }
      );
    }

    if (!user) {
      return NextResponse.json(
        {
          error: "المستخدم غير موجود",
        },
        {
          status: 404,
        }
      );
    }

    if (user.is_active === false) {
      return NextResponse.json(
        {
          error: "هذا الحساب غير نشط",
        },
        {
          status: 403,
        }
      );
    }

    /* =====================================================
       الأسبوع الحالي
    ===================================================== */

    const {
      data: currentWeekId,
      error: weekIdError,
    } = await supabaseAdmin.rpc("get_current_week");

    if (weekIdError || !currentWeekId) {
      console.error(
        "CURRENT WEEK ERROR:",
        weekIdError
      );

      return NextResponse.json(
        {
          error: "تعذر تحديد الأسبوع الحالي",
          details: weekIdError?.message,
        },
        {
          status: 500,
        }
      );
    }

    /* =====================================================
       بيانات الأسبوع الحالي
    ===================================================== */

    const {
      data: currentWeek,
      error: currentWeekError,
    } = await supabaseAdmin
      .from("weekly_periods")
      .select(
        "id, start_at, end_at, is_closed, closed_at"
      )
      .eq("id", currentWeekId)
      .maybeSingle();

    if (currentWeekError) {
      console.error(
        "CURRENT WEEK DATA ERROR:",
        currentWeekError
      );

      return NextResponse.json(
        {
          error:
            "تعذر تحميل بيانات الأسبوع الحالي",
          details: currentWeekError.message,
        },
        {
          status: 500,
        }
      );
    }

    /* =====================================================
       نشاط المستخدم في الأسبوع الحالي
    ===================================================== */

    const {
      data: activity,
      error: activityError,
    } = await supabaseAdmin
      .from("weekly_user_activity")
      .select(
        `
          id,
          week_id,
          user_id,
          is_active,
          floor_charged,
          produced_total,
          consumed_total,
          produced_count,
          consumed_count,
          created_at,
          updated_at
        `
      )
      .eq("week_id", currentWeekId)
      .eq("user_id", userId)
      .maybeSingle();

    if (activityError) {
      console.error(
        "DASHBOARD ACTIVITY ERROR:",
        activityError
      );

      return NextResponse.json(
        {
          error: "تعذر تحميل نشاط الأسبوع",
          details: activityError.message,
        },
        {
          status: 500,
        }
      );
    }

    /* =====================================================
       الطلبات المنتجة في الأسبوع الحالي
    ===================================================== */

    const {
      data: producedOrders,
      error: producedError,
    } = await supabaseAdmin
      .from("orders")
      .select(
        `
          id,
          order_number,
          order_type,
          amount,
          commission_rate,
          commission_amount,
          producer_id,
          consumer_id,
          status,
          notes,
          created_at,
          updated_at,
          financially_processed,
          processed_week_id,
          consumer:users!orders_consumer_id_fkey (
            id,
            full_name,
            phone
          )
        `
      )
      .eq("producer_id", userId)
      .eq("processed_week_id", currentWeekId)
      .neq("status", "cancelled")
      .order("created_at", {
        ascending: false,
      });

    if (producedError) {
      console.error(
        "PRODUCED ORDERS ERROR:",
        producedError
      );

      return NextResponse.json(
        {
          error:
            "تعذر تحميل الطلبات المنتجة",
          details: producedError.message,
        },
        {
          status: 500,
        }
      );
    }

    /* =====================================================
       الطلبات المستهلكة في الأسبوع الحالي
    ===================================================== */

    const {
      data: consumedOrders,
      error: consumedError,
    } = await supabaseAdmin
      .from("orders")
      .select(
        `
          id,
          order_number,
          order_type,
          amount,
          commission_rate,
          commission_amount,
          producer_id,
          consumer_id,
          status,
          notes,
          created_at,
          updated_at,
          financially_processed,
          processed_week_id,
          producer:users!orders_producer_id_fkey (
            id,
            full_name,
            phone
          )
        `
      )
      .eq("consumer_id", userId)
      .eq("processed_week_id", currentWeekId)
      .neq("status", "cancelled")
      .order("created_at", {
        ascending: false,
      });

    if (consumedError) {
      console.error(
        "CONSUMED ORDERS ERROR:",
        consumedError
      );

      return NextResponse.json(
        {
          error:
            "تعذر تحميل الطلبات المستهلكة",
          details: consumedError.message,
        },
        {
          status: 500,
        }
      );
    }

    /* =====================================================
       آخر المعاملات المالية للأسبوع الحالي
    ===================================================== */

    const {
      data: transactions,
      error: transactionsError,
    } = await supabaseAdmin
      .from("transactions")
      .select(
        `
          id,
          transaction_type,
          amount,
          balance_before,
          balance_after,
          order_id,
          week_id,
          description,
          created_at
        `
      )
      .eq("user_id", userId)
      .eq("week_id", currentWeekId)
      .order("created_at", {
        ascending: false,
      })
      .limit(20);

    if (transactionsError) {
      console.error(
        "DASHBOARD TRANSACTIONS ERROR:",
        transactionsError
      );

      return NextResponse.json(
        {
          error:
            "تعذر تحميل الحركات المالية",
          details: transactionsError.message,
        },
        {
          status: 500,
        }
      );
    }

    /* =====================================================
       الإحصائيات
    ===================================================== */

    const produced = activity
      ? {
          total: Number(
            activity.produced_total || 0
          ),
          count: Number(
            activity.produced_count || 0
          ),
        }
      : {
          total: 0,
          count: 0,
        };

    const consumed = activity
      ? {
          total: Number(
            activity.consumed_total || 0
          ),
          count: Number(
            activity.consumed_count || 0
          ),
        }
      : {
          total: 0,
          count: 0,
        };

    const totalOperations =
      produced.count + consumed.count;

    /* =====================================================
       الرد النهائي
    ===================================================== */

    return NextResponse.json({
      success: true,

      user,

      currentWeek: currentWeek || null,

      activity:
        activity || {
          is_active: false,
          floor_charged: false,
          produced_total: 0,
          consumed_total: 0,
          produced_count: 0,
          consumed_count: 0,
        },

      statistics: {
        producedTotal: produced.total,
        consumedTotal: consumed.total,
        producedCount: produced.count,
        consumedCount: consumed.count,
        totalOperations,
      },

      producedOrders:
        producedOrders || [],

      consumedOrders:
        consumedOrders || [],

      transactions:
        transactions || [],
    });
  } catch (error) {
    console.error(
      "DASHBOARD API ERROR:",
      error
    );

    return NextResponse.json(
      {
        error:
          "حدث خطأ أثناء تحميل لوحة التحكم",
      },
      {
        status: 500,
      }
    );
  }
}