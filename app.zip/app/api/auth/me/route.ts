import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";
import crypto from "crypto";

type SessionPayload = {
  userId: string;
  role: string;
  exp: number;
};

function verifySession(token: string): SessionPayload | null {
  try {
    const secret = process.env.AUTH_SESSION_SECRET;

    if (!secret) {
      throw new Error("AUTH_SESSION_SECRET غير موجود");
    }

    const parts = token.split(".");

    if (parts.length !== 2) {
      return null;
    }

    const [encodedPayload, signature] = parts;

    const expectedSignature = crypto
      .createHmac("sha256", secret)
      .update(encodedPayload)
      .digest("base64url");

    const signatureBuffer = Buffer.from(signature);
    const expectedBuffer = Buffer.from(expectedSignature);

    if (
      signatureBuffer.length !== expectedBuffer.length ||
      !crypto.timingSafeEqual(signatureBuffer, expectedBuffer)
    ) {
      return null;
    }

    const payload = JSON.parse(
      Buffer.from(encodedPayload, "base64url").toString("utf8")
    ) as SessionPayload;

    if (!payload.userId || !payload.exp) {
      return null;
    }

    if (Date.now() > payload.exp) {
      return null;
    }

    return payload;
  } catch (error) {
    console.error("VERIFY SESSION ERROR:", error);
    return null;
  }
}

export async function GET(request: Request) {
  try {
    const authHeader = request.headers.get("authorization");

    if (!authHeader?.startsWith("Bearer ")) {
      return NextResponse.json(
        { error: "غير مصرح" },
        { status: 401 }
      );
    }

    const token = authHeader.substring(7).trim();

    if (!token) {
      return NextResponse.json(
        { error: "جلسة الدخول غير صالحة" },
        { status: 401 }
      );
    }

    const session = verifySession(token);

    if (!session) {
      return NextResponse.json(
        { error: "جلسة الدخول غير صالحة أو منتهية" },
        { status: 401 }
      );
    }

    const supabase = createClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.SUPABASE_SECRET_KEY!
    );

    const { data: user, error } = await supabase
      .from("users")
      .select("*")
      .eq("id", session.userId)
      .is("deleted_at", null)
      .maybeSingle();

    if (error) {
      console.error("ME USERS ERROR:", error);

      return NextResponse.json(
        {
          error: "تعذر قراءة بيانات المستخدم",
          details: error.message,
        },
        { status: 500 }
      );
    }

    if (!user) {
      return NextResponse.json(
        { error: "الحساب غير موجود" },
        { status: 404 }
      );
    }

    if (user.is_active === false) {
      return NextResponse.json(
        { error: "هذا الحساب غير نشط" },
        { status: 403 }
      );
    }

    return NextResponse.json({
      success: true,
      user,
    });
  } catch (error) {
    console.error("ME API ERROR:", error);

    return NextResponse.json(
      {
        error: "حدث خطأ أثناء تحميل بيانات الحساب",
      },
      { status: 500 }
    );
  }
}